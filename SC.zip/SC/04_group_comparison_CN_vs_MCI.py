"""
Script 4: Node-wise group comparison (CN vs MCI) across parcellation schemes.

Splits results into SUBC atlases (DKT, FC-Schaefer2018, FC-Glasser) and
noSUBC atlases (FC-Desikan, Schaefer2018, glasser360MNI), each saved in its
own subfolder with unified naming: Desikan, Schaefer, Glasser.

For each group:
  1. Mann-Whitney U test at each node (CN vs MCI)
  2. FDR correction
  3. Cohen's d effect sizes
  4. Sensitivity comparison across atlases

Usage:
  python 04_group_comparison_CN_vs_MCI.py --dir /path/to/data --diag /path/to/diag.csv --plots /path/to/plots
  python 04_group_comparison_CN_vs_MCI.py --dir /path/to/data --diag /path/to/diag.csv --plots /path/to/plots --subset-dir /path/to/FC_matrics
"""

import os
import re
import glob
import argparse
import warnings
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
from scipy.stats import mannwhitneyu
from statsmodels.stats.multitest import multipletests

warnings.filterwarnings("ignore", category=FutureWarning)

matplotlib.rcParams["font.family"] = "Helvetica"
matplotlib.rcParams["font.size"] = 14
matplotlib.rcParams["axes.titlesize"] = 16
matplotlib.rcParams["axes.labelsize"] = 14
matplotlib.rcParams["xtick.labelsize"] = 12
matplotlib.rcParams["ytick.labelsize"] = 12
matplotlib.rcParams["legend.fontsize"] = 12
matplotlib.rcParams["figure.titlesize"] = 18
matplotlib.rcParams["pdf.fonttype"] = 42

METRIC_NAMES = ["strength", "clustering", "betweenness", "closeness"]

# Atlas grouping and renaming
SUBC_ATLAS_MAP = {"DKT": "Desikan", "FC-Schaefer2018": "Schaefer", "FC-Glasser": "Glasser"}
noSUBC_ATLAS_MAP = {"FC-Desikan": "Desikan", "Schaefer2018": "Schaefer", "glasser360MNI": "Glasser"}

ATLAS_GROUPS = {
    "SUBC_atlases": SUBC_ATLAS_MAP,
    "noSUBC_atlases": noSUBC_ATLAS_MAP,
}

PLAIN_COLORS = {
    "Desikan": "#D85A30",
    "Schaefer": "#1D9E75",
    "Glasser": "#378ADD",
}


def get_color(atlas):
    return PLAIN_COLORS.get(atlas, "#888780")

def display_tag(tag):
    return {"all": "full population", "shared_FC-SC": "FC subset"}.get(tag, tag)


# ── Load diagnostic labels ────────────────────────────────────────────────

def load_diagnoses(diag_path):
    df = pd.read_csv(diag_path)

    # Diagnosis per subject: row with the lowest Visit Number in the file
    df_sorted = df.sort_values(["Subject ID", "Visit Number"])
    diag_per_subj = df_sorted.groupby("Subject ID")["DIAGNOSTIC CLASS"].first()

    def to_folder_id(sid):
        return "sub-" + sid.replace("_", "").replace("S", "S")

    labels = {}
    for sid, diag in diag_per_subj.items():
        if diag in ("CN", "MCI"):
            labels[to_folder_id(sid)] = diag

    return labels


# ── Load nodal data ───────────────────────────────────────────────────────

def load_nodal_data(input_dir):
    rows = []
    for subj_dir in sorted(glob.glob(os.path.join(input_dir, "sub-*"))):
        if not os.path.isdir(subj_dir):
            continue
        for csv_path in sorted(glob.glob(os.path.join(subj_dir, "*_nodal_metrics.csv"))):
            fname = os.path.basename(csv_path)
            match = re.match(r"(sub-[^_]+)_(.+)_nodal_metrics", fname.replace(".csv", ""))
            if not match:
                continue
            df = pd.read_csv(csv_path)
            df["subject"] = match.group(1)
            df["atlas"] = match.group(2)
            rows.append(df)

    if not rows:
        raise FileNotFoundError("No nodal_metrics.csv files found.")
    return pd.concat(rows, ignore_index=True)


def get_subject_ids(directory):
    return {n for n in os.listdir(directory)
            if n.startswith("sub-") and os.path.isdir(os.path.join(directory, n))}


def filter_and_rename(data, atlas_map):
    filtered = data[data["atlas"].isin(atlas_map.keys())].copy()
    filtered["atlas"] = filtered["atlas"].map(atlas_map)
    return filtered


# ── Cohen's d ─────────────────────────────────────────────────────────────

def cohens_d(a, b):
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return 0.0
    var_a = np.var(a, ddof=1)
    var_b = np.var(b, ddof=1)
    pooled_std = np.sqrt(((na - 1) * var_a + (nb - 1) * var_b) / (na + nb - 2))
    if pooled_std == 0:
        return 0.0
    return (np.mean(a) - np.mean(b)) / pooled_std


# ── Node-wise group comparison ────────────────────────────────────────────

def run_nodewise_comparison(data, labels, plots_dir, tag):
    data = data.copy()
    data["group"] = data["subject"].map(labels)
    data = data.dropna(subset=["group"])

    atlases = sorted(data["atlas"].unique())

    subj_groups = data.groupby("subject")["group"].first()
    cn_count = (subj_groups == "CN").sum()
    mci_count = (subj_groups == "MCI").sum()
    print(f"    Subjects with labels: {len(subj_groups)} (CN={cn_count}, MCI={mci_count})")

    all_node_results = []
    sensitivity_rows = []

    for atlas in atlases:
        atlas_data = data[data["atlas"] == atlas]

        for metric in METRIC_NAMES:
            col = f"{metric}_z"
            if col not in atlas_data.columns:
                continue

            pivot = atlas_data.pivot(index="subject", columns="node_index", values=col)
            pivot = pivot.dropna(axis=1, how="all")

            groups = atlas_data.groupby("subject")["group"].first()
            cn_subjs = groups[groups == "CN"].index
            mci_subjs = groups[groups == "MCI"].index

            cn_data = pivot.loc[pivot.index.isin(cn_subjs)].values
            mci_data = pivot.loc[pivot.index.isin(mci_subjs)].values
            node_indices = pivot.columns.values

            n_nodes = cn_data.shape[1]
            p_vals = np.zeros(n_nodes)
            u_stats = np.zeros(n_nodes)
            effect_sizes = np.zeros(n_nodes)

            for i in range(n_nodes):
                cn_vals = cn_data[:, i][~np.isnan(cn_data[:, i])]
                mci_vals = mci_data[:, i][~np.isnan(mci_data[:, i])]

                if len(cn_vals) < 3 or len(mci_vals) < 3:
                    p_vals[i] = 1.0
                    u_stats[i] = np.nan
                    effect_sizes[i] = 0.0
                    continue

                u_stat, p_val = mannwhitneyu(cn_vals, mci_vals, alternative="two-sided")
                u_stats[i] = u_stat
                p_vals[i] = p_val
                effect_sizes[i] = cohens_d(cn_vals, mci_vals)

            rejected, p_corrected, _, _ = multipletests(p_vals, method="fdr_bh")

            for i in range(n_nodes):
                all_node_results.append({
                    "atlas": atlas, "metric": metric,
                    "node_index": int(node_indices[i]),
                    "U_statistic": u_stats[i],
                    "p_value": p_vals[i], "p_fdr": p_corrected[i],
                    "significant_fdr05": rejected[i],
                    "cohens_d": effect_sizes[i],
                    "mean_CN": np.nanmean(cn_data[:, i]),
                    "mean_MCI": np.nanmean(mci_data[:, i]),
                })

            n_sig = rejected.sum()
            mean_d = np.mean(np.abs(effect_sizes))
            mean_d_sig = np.mean(np.abs(effect_sizes[rejected])) if n_sig > 0 else 0.0
            max_d = np.max(np.abs(effect_sizes))

            sensitivity_rows.append({
                "atlas": atlas, "metric": metric, "n_nodes": n_nodes,
                "n_significant_fdr05": int(n_sig),
                "pct_significant": round(100 * n_sig / n_nodes, 1),
                "mean_abs_cohens_d": round(mean_d, 4),
                "mean_abs_cohens_d_sig": round(mean_d_sig, 4),
                "max_abs_cohens_d": round(max_d, 4),
            })

            print(f"      {atlas} / {metric}: {n_sig}/{n_nodes} significant "
                  f"({100*n_sig/n_nodes:.1f}%), mean |d|={mean_d:.3f}")

    node_df = pd.DataFrame(all_node_results)
    node_csv = os.path.join(plots_dir, f"nodewise_group_results_{tag}.csv")
    node_df.to_csv(node_csv, index=False)
    print(f"    Saved: {node_csv}")

    sens_df = pd.DataFrame(sensitivity_rows)
    sens_csv = os.path.join(plots_dir, f"atlas_sensitivity_summary_{tag}.csv")
    sens_df.to_csv(sens_csv, index=False)
    print(f"    Saved: {sens_csv}")

    return node_df, sens_df


# ── Report significant nodes ──────────────────────────────────────────────

def report_significant_nodes(node_df, plots_dir, tag, top_k=10):
    """
    Filter node_df to only significant nodes (FDR < 0.05), sort by |Cohen's d|,
    save as CSV, and print a compact per-(atlas, metric) summary to console.

    Produces:
      - significant_nodes_{tag}.csv  : all significant nodes across atlases/metrics
      - console output               : top-k nodes per (atlas, metric)
    """
    sig = node_df[node_df["significant_fdr05"]].copy()
    if sig.empty:
        print(f"    No significant nodes (FDR < 0.05) in this run.")
        return

    sig["abs_d"] = sig["cohens_d"].abs()
    sig["direction"] = np.where(sig["cohens_d"] > 0, "CN > MCI", "MCI > CN")

    # Sort: atlas, metric, then by |d| descending within each group
    sig = sig.sort_values(
        ["atlas", "metric", "abs_d"], ascending=[True, True, False]
    )

    # Save full filtered CSV
    out_cols = [
        "atlas", "metric", "node_index", "direction",
        "cohens_d", "abs_d",
        "mean_CN", "mean_MCI",
        "U_statistic", "p_value", "p_fdr",
    ]
    sig_csv = os.path.join(plots_dir, f"significant_nodes_{tag}.csv")
    sig[out_cols].to_csv(sig_csv, index=False)
    print(f"    Saved: {sig_csv}   ({len(sig)} significant nodes total)")

    # Per-(atlas, metric) console summary
    print(f"\n    ── Top {top_k} significant nodes per (atlas, metric) [{display_tag(tag)}] ──")
    for (atlas, metric), group in sig.groupby(["atlas", "metric"], sort=True):
        top = group.head(top_k)
        print(f"\n      {atlas} / {metric}  —  {len(group)} significant "
              f"(showing top {min(top_k, len(group))} by |d|)")
        for _, row in top.iterrows():
            print(
                f"        node {int(row['node_index']):>4}  "
                f"d={row['cohens_d']:+.3f}  "
                f"({row['direction']})  "
                f"p_fdr={row['p_fdr']:.2e}"
            )


# ── Plot 1: Significant node counts per atlas ─────────────────────────────

def plot_significant_counts(sens_df, plots_dir, tag):
    fig, axes = plt.subplots(1, 4, figsize=(20, 6))
    fig.suptitle(f"Significant nodes (FDR < 0.05) — CN vs MCI ({display_tag(tag)})", fontsize=18)

    atlases = sorted(sens_df["atlas"].unique())

    global_max = sens_df["n_significant_fdr05"].max()
    y_max = max(global_max * 1.3, 1)

    for ax, metric in zip(axes.flat, METRIC_NAMES):
        metric_data = sens_df[sens_df["metric"] == metric].set_index("atlas")
        metric_data = metric_data.reindex(atlases)

        colors = [get_color(a) for a in atlases]
        bars = ax.bar(range(len(atlases)), metric_data["n_significant_fdr05"], color=colors)

        for bar, (_, row) in zip(bars, metric_data.iterrows()):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2., height + y_max * 0.03,
                    f"{row['pct_significant']:.1f}%",
                    ha="center", va="bottom", fontsize=12, fontweight="medium")

        ax.set_title(metric.capitalize(), fontsize=16)
        ax.set_xticks(range(len(atlases)))
        ax.set_xticklabels(atlases, rotation=45, ha="right", fontsize=12)
        ax.set_ylabel("Significant nodes" if ax == axes[0] else "")
        ax.set_ylim(0, y_max)
        ax.yaxis.set_major_locator(mticker.MaxNLocator(integer=True))
        ax.yaxis.grid(True, linewidth=0.3, color="grey", alpha=0.5)
        ax.xaxis.grid(False)
        ax.set_axisbelow(True)

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    path = os.path.join(plots_dir, f"significant_nodes_per_atlas_{tag}.pdf")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"    Saved: {path}")


# ── Plot 2: Effect size distributions ─────────────────────────────────────

def plot_effect_sizes(node_df, plots_dir, tag):
    fig, axes = plt.subplots(2, 2, figsize=(16, 11))
    fig.suptitle(f"Cohen's d distribution per atlas — CN vs MCI ({display_tag(tag)})", fontsize=18)

    atlases = sorted(node_df["atlas"].unique())

    for ax, metric in zip(axes.flat, METRIC_NAMES):
        metric_data = node_df[node_df["metric"] == metric]

        for atlas in atlases:
            vals = metric_data.loc[metric_data["atlas"] == atlas, "cohens_d"].dropna()
            if len(vals) == 0:
                continue
            sns.kdeplot(vals, ax=ax, label=atlas, color=get_color(atlas), linewidth=2)

        ax.axvline(x=0, color="grey", linewidth=0.5, linestyle="--")
        ax.set_title(metric.capitalize(), fontsize=16)
        ax.set_xlabel("Cohen's d (CN - MCI)", fontsize=14)
        ax.set_ylabel("Density", fontsize=14, labelpad=10)
        ax.tick_params(axis="both", labelsize=14)
        ax.legend(fontsize=10)
        ax.yaxis.grid(True, linewidth=0.3, color="grey", alpha=0.5)
        ax.xaxis.grid(False)
        ax.set_axisbelow(True)

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    path = os.path.join(plots_dir, f"effect_size_distributions_{tag}.pdf")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"    Saved: {path}")


# ── Plot 3: Atlas sensitivity heatmap ─────────────────────────────────────

def plot_sensitivity_heatmap(sens_df, plots_dir, tag):
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle(f"Atlas sensitivity to CN vs MCI differences ({display_tag(tag)})", fontsize=18)

    atlases = sorted(sens_df["atlas"].unique())

    pivot_pct = sens_df.pivot(index="atlas", columns="metric", values="pct_significant")
    pivot_pct = pivot_pct.reindex(index=atlases, columns=METRIC_NAMES)
    sns.heatmap(
        pivot_pct, ax=axes[0], annot=True, fmt=".1f", cmap="YlOrRd",
        linewidths=0.5
    )
    axes[0].set_title("% significant nodes (FDR < 0.05)", fontsize=14)
    axes[0].set_xlabel("")
    axes[0].set_ylabel("")
    axes[0].tick_params(axis="x", rotation=45, labelsize=12)
    axes[0].tick_params(axis="y", rotation=0, labelsize=12)

    pivot_d = sens_df.pivot(index="atlas", columns="metric", values="mean_abs_cohens_d_sig")
    pivot_d = pivot_d.reindex(index=atlases, columns=METRIC_NAMES)
    sns.heatmap(
        pivot_d, ax=axes[1], annot=True, fmt=".3f", cmap="YlOrRd",
        linewidths=0.5
    )
    axes[1].set_title("Mean |Cohen's d| of significant nodes", fontsize=14)
    axes[1].set_xlabel("")
    axes[1].set_ylabel("")
    axes[1].tick_params(axis="x", rotation=45, labelsize=12)
    axes[1].tick_params(axis="y", rotation=0, labelsize=12)

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    path = os.path.join(plots_dir, f"atlas_sensitivity_heatmap_{tag}.pdf")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"    Saved: {path}")


# ── Run all for a given dataset ────────────────────────────────────────────

def run_all(data, labels, plots_dir, tag):
    data_labelled = data[data["subject"].isin(labels.keys())]
    subjects = sorted(data_labelled["subject"].unique())
    atlases = sorted(data_labelled["atlas"].unique())

    subj_groups = {s: labels[s] for s in subjects if s in labels}
    cn = sum(1 for v in subj_groups.values() if v == "CN")
    mci = sum(1 for v in subj_groups.values() if v == "MCI")
    print(f"\n    ── {tag}: {len(subjects)} subjects (CN={cn}, MCI={mci}), "
          f"atlases: {atlases} ──")

    if data_labelled.empty:
        print("    No labelled data, skipping.")
        return

    node_df, sens_df = run_nodewise_comparison(data_labelled, labels, plots_dir, tag)

    report_significant_nodes(node_df, plots_dir, tag)

    plot_significant_counts(sens_df, plots_dir, tag)
    plot_effect_sizes(node_df, plots_dir, tag)
    plot_sensitivity_heatmap(sens_df, plots_dir, tag)


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Node-wise group comparison (CN vs MCI) across atlases."
    )
    parser.add_argument("--dir", required=True,
                        help="Root data directory with subject folders")
    parser.add_argument("--diag", required=True,
                        help="Path to longitudinal_ADNI_filtering_FINAL.csv")
    parser.add_argument("--plots", required=True,
                        help="Directory to save results and plots")
    parser.add_argument("--subset-dir", default=None,
                        help="Optional: directory with subject folders to define "
                             "the shared subset (e.g. FC group data)")
    args = parser.parse_args()

    os.makedirs(args.plots, exist_ok=True)

    # Load diagnoses
    print("Loading diagnostic labels...")
    labels = load_diagnoses(args.diag)
    cn_count = sum(1 for v in labels.values() if v == "CN")
    mci_count = sum(1 for v in labels.values() if v == "MCI")
    print(f"  Diagnostic file: {cn_count} CN, {mci_count} MCI")

    # Load nodal data
    print("\nLoading nodal metrics...")
    data = load_nodal_data(args.dir)
    print(f"  Loaded {data['subject'].nunique()} subjects, "
          f"{data['atlas'].nunique()} atlases")

    # Determine shared subjects if --subset-dir provided
    shared_subjects = None
    if args.subset_dir:
        fc_subjects = get_subject_ids(args.subset_dir)
        all_subjects = set(data["subject"].unique())
        shared_subjects = all_subjects & fc_subjects
        if not shared_subjects:
            print(f"Warning: no overlapping subjects with {args.subset_dir}")
            shared_subjects = None
        else:
            print(f"Found {len(shared_subjects)} shared subjects with FC group.")

    # ── Run for each atlas group (SUBC / noSUBC) ──────────────────────
    for group_name, atlas_map in ATLAS_GROUPS.items():
        group_dir = os.path.join(args.plots, group_name)
        os.makedirs(group_dir, exist_ok=True)
        print(f"\n{'='*60}")
        print(f"  Atlas group: {group_name}")
        print(f"{'='*60}")

        group_data = filter_and_rename(data, atlas_map)

        if group_data.empty:
            print(f"  No data for {group_name}, skipping.")
            continue

        # Full population
        run_all(group_data, labels, group_dir, tag="all")

        # Shared subset
        if shared_subjects is not None:
            shared_data = group_data[group_data["subject"].isin(shared_subjects)]
            if not shared_data.empty:
                run_all(shared_data, labels, group_dir, tag="shared_FC-SC")

    print("\nAll done.")


if __name__ == "__main__":
    main()
