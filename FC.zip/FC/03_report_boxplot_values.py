"""
Script 3 (FC version): Report the summary values underlying the aggregate
boxplots (median across subjects of each per-subject median/Gini), matching
the exact logic of the FC version of 02_compare_atlases.py.

Differences from the SC summary script, all mirroring the FC plotting script:
  - FC atlas names/grouping (SUBC / noSUBC) are the ones used in the FC
    plotting script.
  - The per-(subject, atlas) aggregates are NOT read from
    summary_aggregates.csv. They are recomputed from the per-subject
    *_nodal_metrics.csv files, exactly as the FC plotting script does
    (compute_summary_from_nodal), because summary_aggregates.csv can be
    overwritten by different 01a/01b extraction runs.
  - --subset-dir is optional (if omitted, only the "all" subset is reported);
    if there is no overlap, a warning is printed and only "all" is reported.
  - --exclude removes specific subject IDs from the shared subset after
    --subset-dir is applied (same behaviour as the plotting script).

For each atlas group, subset, atlas, metric and stat type it reports the value
each boxplot box is centered on (median of the per-subject median_/gini_
values) plus quartiles/IQR, so exact numbers can be quoted in the text.

Usage:
  python 03_report_boxplot_values.py --input /path/to/FC_data \
      --out /path/to/results/boxplot_medians_FC.csv
  python 03_report_boxplot_values.py --input /path/to/FC_data \
      --subset-dir /path/to/subset_subjects \
      [--exclude sub-XXXX sub-YYYY] \
      --out /path/to/results/boxplot_medians_FC.csv
"""

import os
import glob
import re
import argparse
import numpy as np
import pandas as pd

METRIC_NAMES = ["strength", "clustering", "betweenness", "closeness"]

# Same atlas grouping/renaming as the FC plotting script
SUBC_ATLAS_MAP = {"Desikan_subcortical_FC": "Desikan", "Schaefer100_subcortical_FC": "Schaefer", "Glasser": "Glasser"}
noSUBC_ATLAS_MAP = {"Desikan": "Desikan", "Schaefer100": "Schaefer", "Glasser_cortical": "Glasser"}

ATLAS_GROUPS = {
    "SUBC_atlases": SUBC_ATLAS_MAP,
    "noSUBC_atlases": noSUBC_ATLAS_MAP,
}


# ── Identical to the FC plotting script ────────────────────────────────────

def load_nodal_data(input_dir):
    rows = []
    for subj_dir in sorted(glob.glob(os.path.join(input_dir, "sub-*"))):
        if not os.path.isdir(subj_dir):
            continue
        for csv_path in sorted(glob.glob(os.path.join(subj_dir, "*_nodal_metrics.csv"))):
            fname = os.path.basename(csv_path)
            match = re.match(r"(sub-[^_]+)_(.+)_nodal_metrics", fname.replace(".csv", ""))
            if not match:
                continue
            df = pd.read_csv(csv_path)
            df["subject"] = match.group(1)
            df["atlas"] = match.group(2)
            rows.append(df)

    if not rows:
        raise FileNotFoundError("No nodal_metrics.csv files found.")
    return pd.concat(rows, ignore_index=True)


def get_subject_ids(directory):
    return {n for n in os.listdir(directory)
            if n.startswith("sub-") and os.path.isdir(os.path.join(directory, n))}


def gini_coefficient(values):
    """Compute Gini coefficient for a 1D array of non-negative values.
    Kept identical to the one in 01*_extract_fc_metrics_*.py for consistency."""
    v = np.sort(np.abs(values))
    n = len(v)
    if n == 0 or v.sum() == 0:
        return 0.0
    index = np.arange(1, n + 1)
    return (2 * np.sum(index * v) - (n + 1) * np.sum(v)) / (n * np.sum(v))


def compute_summary_from_nodal(data):
    """Per-(subject, atlas) aggregates, computed exactly as in the FC
    plotting script (median of z-scored values, Gini of raw values)."""
    rows = []
    for (subject, atlas), grp in data.groupby(["subject", "atlas"]):
        row = {"subject": subject, "atlas": atlas}
        for m in METRIC_NAMES:
            z_col, raw_col = f"{m}_z", m
            if z_col not in grp.columns or raw_col not in grp.columns:
                continue
            z = grp[z_col].values
            raw = grp[raw_col].values
            row[f"{m}_median"] = np.median(z)
            row[f"{m}_gini"] = gini_coefficient(raw)
            row[f"{m}_p25"] = np.percentile(z, 25)
            row[f"{m}_p75"] = np.percentile(z, 75)
        rows.append(row)
    return pd.DataFrame(rows)


def filter_and_rename(data, atlas_map):
    """Filter data to atlases in atlas_map and rename to plain names."""
    filtered = data[data["atlas"].isin(atlas_map.keys())].copy()
    filtered["atlas"] = filtered["atlas"].map(atlas_map)
    return filtered


# ── Summary of the values shown in the aggregate boxplots ──────────────────

def summarize(summary_df, group_name, tag):
    """Per atlas/metric/stat: the statistics of the per-subject values that
    the boxplot in plot_aggregates() draws (all subjects with a non-NaN
    value, as seaborn drops NaNs; quartiles use linear interpolation, the
    same as matplotlib's boxplot)."""
    rows = []
    atlases = sorted(summary_df["atlas"].unique())
    for atlas in atlases:
        sub = summary_df[summary_df["atlas"] == atlas]
        for metric in METRIC_NAMES:
            for stat_type in ["median", "gini"]:
                col = f"{metric}_{stat_type}"
                if col not in sub.columns:
                    continue
                vals = sub[col].dropna()
                if len(vals) == 0:
                    continue
                q25 = vals.quantile(0.25)
                q75 = vals.quantile(0.75)
                rows.append({
                    "atlas_group": group_name,
                    "subset": tag,
                    "atlas": atlas,
                    "metric": metric,
                    "stat_type": stat_type,
                    "n_subjects": len(vals),
                    "median": round(vals.median(), 4),
                    "q25": round(q25, 4),
                    "q75": round(q75, 4),
                    "iqr_range": round(q75 - q25, 4),
                    "mean": round(vals.mean(), 4),
                    "std": round(vals.std(), 4),
                })
    return rows


def print_block(df, group_name, tag):
    block = df[(df["subset"] == tag) & (df["atlas_group"] == group_name)]
    if block.empty:
        return
    print(f"\n--- {group_name}, {tag} ---")
    for _, r in block.sort_values(["metric", "stat_type", "atlas"]).iterrows():
        print(f"{r['metric']:12s} {r['stat_type']:7s} {r['atlas']:8s} "
              f"median={r['median']:.3f}  IQR=[{r['q25']:.3f}, {r['q75']:.3f}] "
              f"(range={r['iqr_range']:.3f})  n={r['n_subjects']}")


def main():
    parser = argparse.ArgumentParser(
        description="Report boxplot-underlying median/Gini values (FC atlases)."
    )
    parser.add_argument("--input", required=True,
                        help="Root data directory with sub-*/..._nodal_metrics.csv "
                             "(same --input as the FC plotting script)")
    parser.add_argument("--subset-dir", default=None,
                        help="Optional: directory with subject folders defining the "
                             "shared subset (same --subset-dir as the plotting script)")
    parser.add_argument("--exclude", nargs="+", default=None,
                        help="Optional: subject IDs to remove from the shared subset "
                             "after --subset-dir is applied (same as the plotting script)")
    parser.add_argument("--out", required=True,
                        help="Path to save the resulting summary CSV")
    args = parser.parse_args()

    print("Loading nodal data...")
    data = load_nodal_data(args.input)

    # Shared subset -- same logic as the FC plotting script
    shared_subjects = None
    if args.subset_dir:
        fc_subjects = get_subject_ids(args.subset_dir)
        all_subjects = set(data["subject"].unique())
        shared_subjects = all_subjects & fc_subjects
        if not shared_subjects:
            print(f"Warning: no overlapping subjects with {args.subset_dir}")
            shared_subjects = None
        else:
            print(f"Found {len(shared_subjects)} shared subjects with FC group "
                  f"(out of {len(all_subjects)} subjects with nodal data).")

    if args.exclude and shared_subjects is not None:
        exclude_set = set(args.exclude)
        not_found = exclude_set - shared_subjects
        if not_found:
            print(f"  Note: {sorted(not_found)} were in --exclude but not in "
                  f"the shared subset to begin with (nothing to remove).")
        removed = shared_subjects & exclude_set
        shared_subjects = shared_subjects - exclude_set
        print(f"  Excluded {len(removed)} subject(s) manually: {sorted(removed)}")
        print(f"  Shared subset after exclusion: {len(shared_subjects)} subjects.")

    all_rows = []
    for group_name, atlas_map in ATLAS_GROUPS.items():
        group_data = filter_and_rename(data, atlas_map)
        if group_data.empty:
            print(f"  No data for {group_name}, skipping.")
            continue
        group_summary = compute_summary_from_nodal(group_data)

        # Full population (tag="all") -> aggregates_boxplots_all.pdf
        all_rows.extend(summarize(group_summary, group_name, tag="all"))

        # Shared subset (tag="shared_FC-SC") -> aggregates_boxplots_shared_FC-SC.pdf
        if shared_subjects is not None:
            shared_data = group_data[group_data["subject"].isin(shared_subjects)]
            shared_summary = group_summary[group_summary["subject"].isin(shared_subjects)]
            if not shared_data.empty and not shared_summary.empty:
                all_rows.extend(summarize(shared_summary, group_name, tag="shared_FC-SC"))
            else:
                print(f"  Warning: no shared-subset rows for {group_name}")

    if not all_rows:
        raise RuntimeError("No summary rows produced -- check atlas names in the nodal CSVs.")

    out_df = pd.DataFrame(all_rows)
    out_dir = os.path.dirname(args.out)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    out_df.to_csv(args.out, index=False)
    print(f"Saved: {args.out}")

    # Readable printout: shared subset if available, otherwise full population
    focus_tag = "shared_FC-SC" if (out_df["subset"] == "shared_FC-SC").any() else "all"
    for group_name in ATLAS_GROUPS:
        print_block(out_df, group_name, focus_tag)


if __name__ == "__main__":
    main()
