"""
Script 2: Visualize and compare nodal metrics across parcellation schemes.

Splits results into SUBC atlases (DKT, FC-Schaefer2018, FC-Glasser) and
noSUBC atlases (FC-Desikan, Schaefer2018, glasser360MNI), each saved in its
own subfolder with unified naming: Desikan, Schaefer, Glasser.

For each group:
  1. Density plots (z-scored distributions per atlas)
  2. Boxplots of aggregate scalars (median, Gini)
  3. Pairwise Kolmogorov-Smirnov tests
  4. Friedman + post-hoc Wilcoxon tests on aggregates

Usage:
  python 02_compare_atlases.py --input /path/to/data --plots /path/to/plots
  python 02_compare_atlases.py --input /path/to/data --plots /path/to/plots --subset-dir /path/to/FC_matrics
"""

import os
import glob
import re
import argparse
import warnings
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
from scipy.stats import ks_2samp, friedmanchisquare, wilcoxon
from statsmodels.stats.multitest import multipletests
from itertools import combinations

warnings.filterwarnings("ignore", category=FutureWarning)

matplotlib.rcParams["font.family"] = "Helvetica"
matplotlib.rcParams["font.size"] = 14
matplotlib.rcParams["axes.titlesize"] = 16
matplotlib.rcParams["axes.labelsize"] = 14
matplotlib.rcParams["xtick.labelsize"] = 12
matplotlib.rcParams["ytick.labelsize"] = 12
matplotlib.rcParams["legend.fontsize"] = 12
matplotlib.rcParams["figure.titlesize"] = 18
matplotlib.rcParams["pdf.fonttype"] = 42

METRIC_NAMES = ["strength", "clustering", "betweenness", "closeness"]

# Atlas grouping and renaming
SUBC_ATLAS_MAP = {"DKT": "Desikan", "FC-Schaefer2018": "Schaefer", "FC-Glasser": "Glasser"}
noSUBC_ATLAS_MAP = {"FC-Desikan": "Desikan", "Schaefer2018": "Schaefer", "glasser360MNI": "Glasser"}

ATLAS_GROUPS = {
    "SUBC_atlases": SUBC_ATLAS_MAP,
    "noSUBC_atlases": noSUBC_ATLAS_MAP,
}

PLAIN_COLORS = {
    "Desikan": "#D85A30",
    "Schaefer": "#1D9E75",
    "Glasser": "#378ADD",
}


def get_color(atlas):
    return PLAIN_COLORS.get(atlas, "#888780")

def display_tag(tag):
    return {"all": "full population", "shared_FC-SC": "FC subset"}.get(tag, tag)

def _darken(hex_color, factor=0.7):
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    r, g, b = int(r * factor), int(g * factor), int(b * factor)
    return f"#{r:02x}{g:02x}{b:02x}"


# ── Load all nodal CSVs ───────────────────────────────────────────────────

def load_nodal_data(input_dir):
    rows = []
    for subj_dir in sorted(glob.glob(os.path.join(input_dir, "sub-*"))):
        if not os.path.isdir(subj_dir):
            continue
        for csv_path in sorted(glob.glob(os.path.join(subj_dir, "*_nodal_metrics.csv"))):
            fname = os.path.basename(csv_path)
            match = re.match(r"(sub-[^_]+)_(.+)_nodal_metrics", fname.replace(".csv", ""))
            if not match:
                continue
            df = pd.read_csv(csv_path)
            df["subject"] = match.group(1)
            df["atlas"] = match.group(2)
            rows.append(df)

    if not rows:
        raise FileNotFoundError("No nodal_metrics.csv files found.")
    return pd.concat(rows, ignore_index=True)


def get_subject_ids(directory):
    return {n for n in os.listdir(directory)
            if n.startswith("sub-") and os.path.isdir(os.path.join(directory, n))}


def filter_and_rename(data, atlas_map):
    """Filter data to atlases in atlas_map and rename to plain names."""
    filtered = data[data["atlas"].isin(atlas_map.keys())].copy()
    filtered["atlas"] = filtered["atlas"].map(atlas_map)
    return filtered


def filter_and_rename_summary(summary_df, atlas_map):
    if summary_df is None:
        return None
    filtered = summary_df[summary_df["atlas"].isin(atlas_map.keys())].copy()
    filtered["atlas"] = filtered["atlas"].map(atlas_map)
    return filtered


# ── Plot 1: Density plots ─────────────────────────────────────────────────

def plot_density(data, plots_dir, tag):
    fig, axes = plt.subplots(2, 2, figsize=(16, 11))
    fig.suptitle(f"Z-scored nodal metric distributions ({display_tag(tag)})", fontsize=18)

    atlases = sorted(data["atlas"].unique())

    ylims = {
        "strength": (0, 3.5),
        "clustering": (0, 1.6),
        "betweenness": (0, 5),
        "closeness": (0, 0.6),
    }

    for ax, metric in zip(axes.flat, METRIC_NAMES):
        col = f"{metric}_z"
        if col not in data.columns:
            ax.set_title(f"{metric} (no z-score column)")
            continue

        for atlas in atlases:
            vals = data.loc[data["atlas"] == atlas, col].dropna()
            if len(vals) == 0:
                continue
            sns.kdeplot(vals, ax=ax, label=atlas, color=get_color(atlas), linewidth=2)

        ax.set_title(metric.capitalize(), fontsize=16)
        ax.set_xlabel("Z-score", fontsize=14)
        ax.set_ylabel("Density", fontsize=14, labelpad=10)
        ax.tick_params(axis="both", labelsize=14)
        ax.legend(fontsize=11)
        ax.xaxis.set_major_locator(mticker.MultipleLocator(2))
        ax.yaxis.grid(True, linewidth=0.3, color="grey", alpha=0.5)
        ax.xaxis.grid(False)
        ax.set_axisbelow(True)
        if metric in ylims:
            ax.set_ylim(ylims[metric])

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    path = os.path.join(plots_dir, f"density_zscore_{tag}.pdf")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


# ── Plot 2: Boxplots of aggregates ────────────────────────────────────────

def plot_aggregates(summary_df, plots_dir, tag):
    fig, axes = plt.subplots(2, 4, figsize=(20, 9))
    fig.suptitle(f"Aggregate metrics by atlas ({display_tag(tag)})", fontsize=18)

    atlases = sorted(summary_df["atlas"].unique())
    palette = {a: get_color(a) for a in atlases}

    for col_idx, metric in enumerate(METRIC_NAMES):
        ax_med = axes[0, col_idx]
        med_col = f"{metric}_median"
        if med_col in summary_df.columns:
            sns.boxplot(
                data=summary_df, x="atlas", y=med_col, ax=ax_med,
                palette=palette, order=atlases, width=0.5
            )
            dark_palette = {a: _darken(get_color(a), 0.7) for a in atlases}
            sns.stripplot(
                data=summary_df, x="atlas", y=med_col, ax=ax_med,
                palette=dark_palette, order=atlases, size=3, alpha=0.6, jitter=True
            )
        ax_med.set_title(f"{metric.capitalize()}", fontsize=16)
        ax_med.set_ylabel("Median (z-scored)", fontsize=13)
        ax_med.set_xlabel("")
        ax_med.set_ylim(-0.4, 0.5)
        ax_med.tick_params(axis="x", rotation=45, labelsize=11)
        ax_med.tick_params(axis="y", labelsize=11)
        ax_med.yaxis.grid(True, linewidth=0.3, color="grey", alpha=0.5)
        ax_med.xaxis.grid(False)
        ax_med.set_axisbelow(True)

        ax_gini = axes[1, col_idx]
        gini_col = f"{metric}_gini"
        if gini_col in summary_df.columns:
            sns.boxplot(
                data=summary_df, x="atlas", y=gini_col, ax=ax_gini,
                palette=palette, order=atlases, width=0.5
            )
            dark_palette = {a: _darken(get_color(a), 0.7) for a in atlases}
            sns.stripplot(
                data=summary_df, x="atlas", y=gini_col, ax=ax_gini,
                palette=dark_palette, order=atlases, size=3, alpha=0.6, jitter=True
            )
        ax_gini.set_title("")
        ax_gini.set_ylabel("Gini coefficient", fontsize=13)
        ax_gini.set_xlabel("")
        ax_gini.set_ylim(-0.01, 1.01)
        ax_gini.tick_params(axis="x", rotation=45, labelsize=11)
        ax_gini.tick_params(axis="y", labelsize=11)
        ax_gini.yaxis.grid(True, linewidth=0.3, color="grey", alpha=0.5)
        ax_gini.xaxis.grid(False)
        ax_gini.set_axisbelow(True)

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    path = os.path.join(plots_dir, f"aggregates_boxplots_{tag}.pdf")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")


# ── Plot 3: Pairwise KS tests ─────────────────────────────────────────────

def compute_ks_tests(data, plots_dir, tag):
    atlases = sorted(data["atlas"].unique())
    all_results = []

    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    fig.suptitle(f"Pairwise KS p-values ({display_tag(tag)})", fontsize=18)

    for ax, metric in zip(axes.flat, METRIC_NAMES):
        col = f"{metric}_z"
        if col not in data.columns:
            continue

        n = len(atlases)
        pval_matrix = np.ones((n, n))

        for (i, a1), (j, a2) in combinations(enumerate(atlases), 2):
            v1 = data.loc[data["atlas"] == a1, col].dropna().values
            v2 = data.loc[data["atlas"] == a2, col].dropna().values
            if len(v1) == 0 or len(v2) == 0:
                continue
            stat, pval = ks_2samp(v1, v2)
            pval_matrix[i, j] = pval
            pval_matrix[j, i] = pval
            all_results.append({
                "metric": metric, "atlas_1": a1, "atlas_2": a2,
                "ks_statistic": round(stat, 4), "p_value": pval,
            })

        log_p = -np.log10(pval_matrix + 1e-300)
        np.fill_diagonal(log_p, 0)
        sns.heatmap(
            log_p, ax=ax, xticklabels=atlases, yticklabels=atlases,
            cmap="YlOrRd", annot=True, fmt=".1f",
            annot_kws={"size": 13}, linewidths=0.5
        )
        ax.set_title(f"{metric.capitalize()}", fontsize=16)
        ax.tick_params(axis="x", rotation=45, labelsize=13)
        ax.tick_params(axis="y", rotation=0, labelsize=13)
        cbar = ax.collections[0].colorbar
        cbar.set_label("-log10(p)", fontsize=13)
        cbar.ax.tick_params(labelsize=11)

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    path = os.path.join(plots_dir, f"ks_pairwise_heatmaps_{tag}.pdf")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path}")

    if all_results:
        ks_df = pd.DataFrame(all_results)
        ks_csv = os.path.join(plots_dir, f"ks_pairwise_results_{tag}.csv")
        ks_df.to_csv(ks_csv, index=False)
        print(f"  Saved: {ks_csv}")


# ── Statistical tests on aggregates ───────────────────────────────────────

def run_aggregate_stats(summary_df, plots_dir, tag):
    atlases = sorted(summary_df["atlas"].unique())
    subjects = sorted(summary_df["subject"].unique())

    complete_subjects = []
    for subj in subjects:
        subj_atlases = set(summary_df.loc[summary_df["subject"] == subj, "atlas"])
        if subj_atlases == set(atlases):
            complete_subjects.append(subj)

    if len(complete_subjects) < 3:
        print(f"  Warning: only {len(complete_subjects)} subjects with all atlases, "
              "skipping statistical tests.")
        return

    print(f"  Running Friedman + Wilcoxon on {len(complete_subjects)} complete subjects...")
    df = summary_df[summary_df["subject"].isin(complete_subjects)].copy()

    aggregate_cols = []
    for m in METRIC_NAMES:
        aggregate_cols.extend([f"{m}_median", f"{m}_gini"])

    all_friedman = []
    all_posthoc = []

    for col in aggregate_cols:
        if col not in df.columns:
            continue

        pivot = df.pivot(index="subject", columns="atlas", values=col)
        pivot = pivot[atlases]
        pivot = pivot.dropna()

        if len(pivot) < 3:
            continue

        groups = [pivot[a].values for a in atlases]
        try:
            stat, pval = friedmanchisquare(*groups)
        except Exception as e:
            print(f"    Friedman failed for {col}: {e}")
            continue

        all_friedman.append({
            "measure": col, "friedman_stat": round(stat, 4),
            "friedman_p": pval, "n_subjects": len(pivot),
        })

        pairs = list(combinations(atlases, 2))
        posthoc_rows = []
        raw_pvals = []

        for a1, a2 in pairs:
            v1, v2 = pivot[a1].values, pivot[a2].values
            try:
                w_stat, w_pval = wilcoxon(v1, v2)
            except Exception:
                w_stat, w_pval = np.nan, np.nan
            posthoc_rows.append({
                "measure": col, "atlas_1": a1, "atlas_2": a2,
                "wilcoxon_stat": round(w_stat, 4) if not np.isnan(w_stat) else np.nan,
                "wilcoxon_p": w_pval,
            })
            raw_pvals.append(w_pval)

        valid_mask = ~np.isnan(raw_pvals)
        corrected = np.full(len(raw_pvals), np.nan)
        if valid_mask.sum() > 0:
            rejected, p_corr, _, _ = multipletests(
                np.array(raw_pvals)[valid_mask], method="fdr_bh"
            )
            corrected[valid_mask] = p_corr

        for i, row in enumerate(posthoc_rows):
            row["wilcoxon_p_fdr"] = corrected[i]
            row["significant_fdr05"] = corrected[i] < 0.05 if not np.isnan(corrected[i]) else False

        all_posthoc.extend(posthoc_rows)

    if all_friedman:
        path = os.path.join(plots_dir, f"friedman_results_{tag}.csv")
        pd.DataFrame(all_friedman).to_csv(path, index=False)
        print(f"  Saved: {path}")

    if all_posthoc:
        path = os.path.join(plots_dir, f"wilcoxon_posthoc_results_{tag}.csv")
        pd.DataFrame(all_posthoc).to_csv(path, index=False)
        print(f"  Saved: {path}")


# ── Run all plots for a given dataset ─────────────────────────────────────

def run_all_plots(data, summary_df, plots_dir, tag):
    subjects = sorted(data["subject"].unique())
    atlases = sorted(data["atlas"].unique())
    print(f"\n  ── {tag}: {len(subjects)} subjects, atlases: {atlases} ──")

    plot_density(data, plots_dir, tag)

    if summary_df is not None and len(summary_df) > 0:
        plot_aggregates(summary_df, plots_dir, tag)
        run_aggregate_stats(summary_df, plots_dir, tag)

    compute_ks_tests(data, plots_dir, tag)


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Visualize nodal metrics across parcellation schemes."
    )
    parser.add_argument("--input", required=True,
                        help="Root data directory (from 01_extract_graph_metrics.py)")
    parser.add_argument("--plots", required=True,
                        help="Directory to save plots")
    parser.add_argument("--subset-dir", default=None,
                        help="Optional: directory with subject folders to define "
                             "the shared subset (e.g. FC group data)")
    args = parser.parse_args()

    os.makedirs(args.plots, exist_ok=True)

    # Load all data
    print("Loading nodal data...")
    data = load_nodal_data(args.input)

    summary_path = os.path.join(args.input, "summary_aggregates.csv")
    summary_df = pd.read_csv(summary_path) if os.path.exists(summary_path) else None

    # Determine shared subjects if --subset-dir provided
    shared_subjects = None
    if args.subset_dir:
        fc_subjects = get_subject_ids(args.subset_dir)
        all_subjects = set(data["subject"].unique())
        shared_subjects = all_subjects & fc_subjects
        if not shared_subjects:
            print(f"Warning: no overlapping subjects with {args.subset_dir}")
            shared_subjects = None
        else:
            print(f"Found {len(shared_subjects)} shared subjects with FC group.")

    # ── Run for each atlas group (SUBC / noSUBC) ──────────────────────
    for group_name, atlas_map in ATLAS_GROUPS.items():
        group_dir = os.path.join(args.plots, group_name)
        os.makedirs(group_dir, exist_ok=True)
        print(f"\n{'='*60}")
        print(f"  Atlas group: {group_name}")
        print(f"{'='*60}")

        # Filter and rename
        group_data = filter_and_rename(data, atlas_map)
        group_summary = filter_and_rename_summary(summary_df, atlas_map)

        if group_data.empty:
            print(f"  No data for {group_name}, skipping.")
            continue

        # Full population
        run_all_plots(group_data, group_summary, group_dir, tag="all")

        # Shared subset
        if shared_subjects is not None:
            shared_data = group_data[group_data["subject"].isin(shared_subjects)]
            shared_summary = (
                group_summary[group_summary["subject"].isin(shared_subjects)]
                if group_summary is not None else None
            )
            if not shared_data.empty:
                run_all_plots(shared_data, shared_summary, group_dir, tag="shared_FC-SC")

    print("\nAll done.")


if __name__ == "__main__":
    main()
