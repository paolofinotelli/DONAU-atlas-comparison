# Structural connectivity (SC): graph-metric extraction and statistics

Code used to extract nodal graph metrics from structural connectivity (SC)
matrices and to compare them across parcellations (Desikan, Schaefer, Glasser)
and between diagnostic groups (CN vs MCI), ADNI cohort.

The scripts are provided exactly as used for the analyses in the paper.

## Contents

| Script | Purpose |
|---|---|
| `01_extract_graph_metrics.py` | Computes nodal metrics for every subject/atlas and writes per-subject CSVs plus `summary_aggregates.csv` |
| `02_compare_atlases.py` | Metric distributions, aggregate boxplots, pairwise KS tests, Friedman + post-hoc Wilcoxon (atlas comparison) |
| `03_report_boxplot_values.py` | Reports the numerical values (median, IQR) behind the aggregate boxplots |
| `04_group_comparison_CN_vs_MCI.py` | Node-wise CN vs MCI comparison (Mann-Whitney U, FDR, Cohen's d) and atlas sensitivity |

Run order: `01` → `02` → `04`. Script `03` is run after `01`, with the same inputs as `02`.


## Installation

Python 3.9+ is recommended.

```bash
pip install -r requirements.txt
```

The plots use the Helvetica font. If it is not installed, matplotlib falls back
to its default font and prints warnings; results are unaffected.

## Data

ADNI data cannot be redistributed. To reproduce the analyses, obtain the data
from ADNI (https://adni.loni.usc.edu) and generate the connectivity matrices
as described in the paper. The scripts expect the following layout:

```
data_SC/
├── sub-002S0413/
│   ├── sub-002S0413_DKT.npy                # connectivity matrix
│   ├── sub-002S0413_DKT_length.npy         # (present in our data, not read by the code)
│   ├── sub-002S0413_Schaefer2018.npy
│   └── ...
├── sub-002S0559/
└── ...
```

- One folder per subject, named `sub-<ID>` (ADNI ID without underscores, e.g. `002_S_0413` → `sub-002S0413`).
- Matrices are named `<subject>_<atlas>.npy`. Files ending in `_length.npy` are not used in the computation.
- The first row and column of each matrix (background node) are discarded by `01_extract_graph_metrics.py`.
- Atlas names found in the SC data and their mapping to the unified names:

| Group | Desikan | Schaefer | Glasser |
|---|---|---|---|
| `SUBC_atlases` (with subcortical) | `DKT` | `FC-Schaefer2018` | `FC-Glasser` |
| `noSUBC_atlases` (cortical only) | `FC-Desikan` | `Schaefer2018` | `glasser360MNI` |

- **Diagnostic file** (`--diag`, step 04): CSV with columns `Subject ID` (e.g. `002_S_0413`), `Visit Number`, `DIAGNOSTIC CLASS`. For each subject, the code uses the diagnosis in the row with the lowest `Visit Number` found in this file (the file contains the diagnosis at the visit used for the analysis; see the paper for how it was matched to the imaging data). Only `CN` and `MCI` are kept.
- **Subset directory** (`--subset-dir`): a directory containing `sub-*` folders that defines the subjects shared with the functional connectivity (FC) analysis. The analyses reported in the paper use the subjects present in both `--dir` and `--subset-dir`; the corresponding output files are suffixed `_shared_FC-SC`. (The scripts also write analogous files suffixed `_all`, covering every subject in `--dir`; these are not used in the paper.)

## Usage

### 1. Extract metrics

```bash
python 01_extract_graph_metrics.py --dir /path/to/data_SC
```

For each matrix this computes, on the weighted undirected matrix:

- strength (`bct.strengths_und`)
- clustering coefficient (`bct.clustering_coef_wu`)
- betweenness centrality (`bct.betweenness_wei`) on lengths = 1/weight (`bct.weight_conversion(W, "lengths")`)
- closeness centrality, computed as the inverse of the mean shortest path length (`bct.distance_wei`)

Outputs:

- `<subject>/<subject>_<atlas>_nodal_metrics.csv`: raw metrics and z-scored metrics (`*_z`, z-scored across nodes within each subject/atlas).
- `summary_aggregates.csv` (in `--dir`): per subject/atlas, median, 25th and 75th percentile of the z-scored metrics, and Gini coefficient of the raw metrics.

Note: `summary_aggregates.csv` is overwritten at each run.

### 2. Atlas comparison

```bash
python 02_compare_atlases.py \
    --input /path/to/data_SC \
    --plots /path/to/results/02_compare_atlases \
    --subset-dir /path/to/FC_data
```

Outputs, in `SUBC_atlases/` and `noSUBC_atlases/`, (files suffixed `_shared_FC-SC`):
density plots of z-scored metrics, aggregate boxplots (median and Gini),
pairwise Kolmogorov-Smirnov tests (heatmaps + CSV), Friedman test and
post-hoc Wilcoxon signed-rank tests (FDR-corrected, Benjamini-Hochberg).

To print the numbers underlying the aggregate boxplots:

```bash
python 03_report_boxplot_values.py \
    --input /path/to/data_SC \
    --subset-dir /path/to/FC_data \
    --out /path/to/results/boxplot_medians.csv
```

### 3. CN vs MCI group comparison

```bash
python 04_group_comparison_CN_vs_MCI.py \
    --dir /path/to/data_SC \
    --diag /path/to/longitudinal_ADNI_filtering_FINAL.csv \
    --plots /path/to/results/04_group_comparison \
    --subset-dir /path/to/FC_data
```

Uses the z-scored metrics. Node-wise Mann-Whitney U tests (CN vs MCI) with FDR
correction and Cohen's d, atlas sensitivity (percentage of significant nodes,
effect sizes), and a list of significant nodes, again in `SUBC_atlases/` and
`noSUBC_atlases/` (files suffixed `_shared_FC-SC`).

## Notes

- `--subset-dir` is required by the SUMMARY script and optional for scripts 03 and 04; without it the `shared_FC-SC` results are not produced.
- Statistical tests use the z-scored metrics (`*_z`) unless stated otherwise in the figure/table.
