"""
Script 1b (MAT-matrix version): Extract nodal graph metrics from PRE-BUILT
functional connectivity matrices stored in .mat files.

Unlike the -TS version, this script does NOT read time series and does NOT
build the FC matrix itself -- it expects each .mat file to already contain a
square connectivity matrix (regions x regions), and uses it as-is.

Supports both classic MATLAB .mat files (readable by scipy.io.loadmat) and
MATLAB v7.3 / HDF5 .mat files (which scipy cannot read; falls back to h5py
automatically). This matters in practice: real files from this pipeline have
been found saved in v7.3/HDF5 format.

Diagonal and negative-value handling (unchanged from the -TS version):
  * Real input matrices checked so far have diagonal = 1 (self-correlation)
    and DO contain negative values (anticorrelations, ~11% of cells in one
    checked subject). Both are handled exactly as before:
    - the diagonal is zeroed by sanitize_matrix() (standard practice, not
      up for debate -- a node has no meaningful self-connection in this
      context);
    - negative weights are handled via --neg (default: "zero", i.e. set to
      0 before computing metrics). THIS IS A METHODOLOGICAL CHOICE, not a
      neutral default -- confirm it matches your analysis, exactly as
      discussed for the -TS version.

Glasser subcortical handling (unchanged in spirit, adapted to matrices):
  If both a full "*_Glasser" matrix and a companion "*_Glasser_subcortical"
  matrix are found for a subject, the script checks whether the subcortical
  matrix is contained as the bottom-right block of the full matrix. If
  confirmed:
    - "Glasser"          -> the full matrix, processed as-is
    - "Glasser_cortical" -> the same matrix with the last N (subcortical)
                             rows AND columns dropped
    - the standalone "*_Glasser_subcortical" matrix is left aside and NOT
      processed on its own.
  If the check fails, both are processed independently and a warning is
  printed. Desikan and Schaefer are unaffected by this logic -- if your
  "*_subcortical" files for those atlases mean something else (e.g. a
  LARGER matrix with subcortical regions ADDED, not a small subcortical-only
  subset -- which is what one uploaded example looked like: an 89x89
  "Desikan_subcortical" file, i.e. 70 Desikan + 19 subcortical, not a 19x19
  subset), they are simply treated as independent atlases and processed
  normally. Flag this if you want the same pairing logic extended to them.

Usage:
  python 01b_extract_fc_metrics_from_matrices.py --dir /path/to/data/FC_matrices
  python 01b_extract_fc_metrics_from_matrices.py --dir /path/to/data --var FC_matrix --neg abs
"""

import os
import re
import argparse
import numpy as np
import pandas as pd
import bct
from scipy.io import loadmat

try:
    import h5py
    _HAS_H5PY = True
except ImportError:
    _HAS_H5PY = False



# Known region counts per atlas, used only for an informational sanity-check
# warning (not for orientation -- matrices are already square, no ambiguity).
ATLAS_REGIONS = {
    "desikan": 70,
    "glasser": 379,
    "schaefer": 100,
}

# Glasser-specific region counts, used only by the subcortical-split logic
# below (kept separate from ATLAS_REGIONS so the generic substring lookup in
# expected_regions() isn't confused by "glasser_subcortical" also containing
# "glasser").
GLASSER_TOTAL_REGIONS = 379
GLASSER_SUBCORTICAL_REGIONS = 19
GLASSER_CORTICAL_REGIONS = GLASSER_TOTAL_REGIONS - GLASSER_SUBCORTICAL_REGIONS  # 360


# -- Helpers -----------------------------------------------------------------

def gini_coefficient(values):
    """Compute Gini coefficient for a 1D array of non-negative values."""
    v = np.sort(np.abs(values))
    n = len(v)
    if n == 0 or v.sum() == 0:
        return 0.0
    index = np.arange(1, n + 1)
    return (2 * np.sum(index * v) - (n + 1) * np.sum(v)) / (n * np.sum(v))


def zscore(v):
    """Z-score a vector. Returns zeros if std is 0."""
    std = np.std(v, ddof=1)
    if std == 0:
        return np.zeros_like(v)
    return (v - np.mean(v)) / std


def expected_regions(atlas_name):
    """Look up the expected region count for an atlas name (substring match).
    Used only for an informational warning, not for any decision-making."""
    a = atlas_name.lower()
    for key, n in ATLAS_REGIONS.items():
        if key in a:
            return n
    return None


# -- Loading -------------------------------------------------------------

def _load_matrix_scipy(path, var_name=None):
    """Load a square matrix from a classic (< v7.3) .mat file via scipy."""
    mat = loadmat(path)
    user_keys = [k for k in mat if not k.startswith("__")]

    if var_name is not None:
        if var_name not in mat:
            print(f"      ! variable '{var_name}' not in file; "
                  f"available: {user_keys}")
            return None
        return np.asarray(mat[var_name], dtype=float)

    candidates = []
    for k in user_keys:
        v = np.asarray(mat[k])
        if v.ndim == 2 and min(v.shape) > 1:
            candidates.append((v.size, k))
    if not candidates:
        print(f"      ! no 2D array found; available: {user_keys}")
        return None

    candidates.sort()
    chosen = candidates[-1][1]
    if len(candidates) > 1:
        print(f"      (auto-selected variable '{chosen}' from {user_keys})")
    return np.asarray(mat[chosen], dtype=float)


def _load_matrix_h5py(path, var_name=None):
    """Load a square matrix from a MATLAB v7.3 (HDF5) .mat file via h5py."""
    if not _HAS_H5PY:
        print(f"      ! {path}: this looks like a MATLAB v7.3/HDF5 file, "
              f"but h5py is not installed. Run: pip install h5py")
        return None

    with h5py.File(path, "r") as f:
        user_keys = [k for k in f.keys() if not k.startswith("#")]

        if var_name is not None:
            if var_name not in f:
                print(f"      ! variable '{var_name}' not in file; "
                      f"available: {user_keys}")
                return None
            return np.asarray(f[var_name], dtype=float)

        candidates = []
        for k in user_keys:
            item = f[k]
            if isinstance(item, h5py.Dataset) and item.ndim == 2 and min(item.shape) > 1:
                candidates.append((item.size, k))
        if not candidates:
            print(f"      ! no 2D dataset found; available: {user_keys}")
            return None

        candidates.sort()
        chosen = candidates[-1][1]
        if len(candidates) > 1:
            print(f"      (auto-selected variable '{chosen}' from {user_keys})")
        return np.asarray(f[chosen], dtype=float)


def load_matrix_from_mat(path, var_name=None):
    """
    Load an already-square connectivity matrix from a .mat file, transparently
    handling both classic and v7.3/HDF5 formats. Returns an ndarray or None.
    """
    try:
        W = _load_matrix_scipy(path, var_name=var_name)
    except NotImplementedError:
        # scipy raises this specifically for v7.3/HDF5 files -- fall back.
        W = _load_matrix_h5py(path, var_name=var_name)

    if W is None:
        return None

    if W.shape[0] != W.shape[1]:
        print(f"      ! {path}: matrix is not square (shape {W.shape}), "
              f"skipping -- this script only processes already-built square "
              f"matrices. Use 01a_extract_fc_metrics_from_timeseries.py for rectangular "
              f"time-series files instead.")
        return None

    return W


# -- FC generation (NEW) -----------------------------------------------------

def expected_regions(atlas_name):
    """Look up the expected region count for an atlas name (substring match)."""
    a = atlas_name.lower()
    for key, n in ATLAS_REGIONS.items():
        if key in a:
            return n
    return None


# -- Glasser subcortical pairing (adapted for pre-built matrices) -----------

def is_glasser_atlas(atlas_name):
    return "glasser" in atlas_name.lower()


def is_subcortical_atlas(atlas_name):
    return "subcortical" in atlas_name.lower()


def check_glasser_subcortical_overlap(W_full, W_sub, atol=1e-6, rtol=1e-5):
    """
    Check whether W_sub (n_sub x n_sub subcortical-only matrix) is contained
    as the BOTTOM-RIGHT n_sub x n_sub block of W_full (n_full x n_full).
    Returns (matched: bool, max_abs_diff: float).
    """
    n_sub = W_sub.shape[0]
    if W_full.shape[0] < n_sub:
        return False, np.inf

    block = W_full[-n_sub:, -n_sub:]
    matched = np.allclose(block, W_sub, atol=atol, rtol=rtol)
    max_diff = float(np.max(np.abs(block - W_sub)))
    return matched, max_diff


def handle_negatives(W, mode):
    """Deal with negative weights before graph metrics. mode: keep|abs|zero."""
    if mode == "keep":
        return W
    if mode == "abs":
        return np.abs(W)
    if mode == "zero":
        return np.where(W < 0, 0.0, W)
    raise ValueError(f"unknown --neg mode: {mode}")


# -- Sanitizing --------------------------------------------------------------

def sanitize_matrix(W, tag):
    """
    Standard cleanups for BCT undirected/weighted metrics: drop NaNs, zero the
    diagonal, symmetrize, and warn about leftover negative weights.
    """
    W = np.asarray(W, dtype=float)

    if np.isnan(W).any():
        print(f"      ! {tag}: matrix contains NaNs -> replaced with 0")
        W = np.nan_to_num(W, nan=0.0)

    if not np.allclose(np.diag(W), 0):
        np.fill_diagonal(W, 0.0)

    asym = float(np.max(np.abs(W - W.T)))
    if asym > 1e-8:
        print(f"      ! {tag}: SYMMETRIZE APPLIED -> max |W - W.T| = {asym:.2e} "
              f"(values near 1e-10 are rounding noise; large values mean the "
              f"input was not a valid undirected matrix, check it)")
        W = (W + W.T) / 2.0

    if (W < 0).any():
        print(f"      ! {tag}: matrix still has NEGATIVE weights -> betweenness/"
              f"closeness will be unreliable (length = 1/W assumes W >= 0)")

    return W


# -- Metric extraction (unchanged) -------------------------------------------

def compute_metrics(W):
    """Compute 4 nodal metrics from a weighted undirected connectivity matrix."""

    strength = bct.strengths_und(W)
    clustering = bct.clustering_coef_wu(W)

    D = bct.weight_conversion(W, "lengths")
    betweenness = bct.betweenness_wei(D)

    shortest_paths = bct.distance_wei(D)[0]
    np.fill_diagonal(shortest_paths, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        mean_sp = np.nanmean(shortest_paths, axis=1)
        closeness = np.where(mean_sp > 0, 1.0 / mean_sp, 0.0)

    return {
        "strength": strength,
        "clustering": clustering,
        "betweenness": betweenness,
        "closeness": closeness,
    }


# -- File parsing / discovery ------------------------------------------------

def parse_filename(fname):
    """
    Parse a .mat filename into (subject_id, atlas_name).
    Expects names like 'sub-002S0413_Desikan_FC.mat'.
    """
    stem = fname[:-4] if fname.lower().endswith(".mat") else fname
    match = re.match(r"(sub-[^_]+)_(.+)", stem)
    if match:
        return match.group(1), match.group(2)
    return stem, "atlas"


def discover_mat_files(root_dir):
    """Recursively find all .mat files, keyed by (subject, atlas)."""
    groups = {}
    for dirpath, _, filenames in os.walk(root_dir):
        for fname in sorted(filenames):
            if not fname.lower().endswith(".mat"):
                continue
            key = parse_filename(fname)
            if key in groups:
                print(f"  ! duplicate key {key}: ignoring "
                      f"{os.path.join(dirpath, fname)}")
                continue
            groups[key] = os.path.join(dirpath, fname)
    return groups


# -- Shared per-matrix processing (steps 5-8, unchanged logic) --------------

def fc_npy_filename(subject_id, atlas_name):
    """
    Build the .npy output filename, avoiding a doubled '_FC_FC' suffix when
    the atlas name already ends in '_FC' (e.g. from a raw filename like
    'Desikan_subcortical_FC.mat'). Only affects the .npy name -- atlas_name
    itself is left untouched everywhere else (CSV filename, 'atlas' column,
    console messages), so nothing loses the '_FC' that was in the original
    filename.
    """
    if atlas_name.lower().endswith("_fc"):
        return f"{subject_id}_{atlas_name}.npy"
    return f"{subject_id}_{atlas_name}_FC.npy"


def process_and_save(subject_id, atlas_name, W, out_dir, args,
                      metric_names, summary_rows):
    """
    Given an already-built (or already-square) connectivity matrix W, run the
    same negative-handling/sanitize/metrics/save steps used for every atlas,
    and append a summary row. Shared by the normal loop and the Glasser
    subcortical-split routine so the logic isn't duplicated.
    """
    tag = f"{subject_id} / {atlas_name}"

    # -- 5. Handle negatives, then 6. sanitize --
    W = handle_negatives(W, args.neg)
    W = sanitize_matrix(W, tag)

    # Save the generated FC matrix so it can be inspected/reused.
    np.save(os.path.join(out_dir, fc_npy_filename(subject_id, atlas_name)), W)

    n_nodes = W.shape[0]
    metrics = compute_metrics(W)

    # -- 7. Build nodal CSV (raw + z-scored) --
    node_data = {"node_index": np.arange(n_nodes)}
    for m in metric_names:
        node_data[m] = metrics[m]
        node_data[f"{m}_z"] = zscore(metrics[m])

    node_df = pd.DataFrame(node_data)
    node_csv = os.path.join(
        out_dir, f"{subject_id}_{atlas_name}_nodal_metrics.csv")
    node_df.to_csv(node_csv, index=False)

    # -- 8. Compute aggregates --
    row = {"subject": subject_id, "atlas": atlas_name, "n_nodes": n_nodes}
    for m in metric_names:
        z = node_data[f"{m}_z"]
        raw = metrics[m]
        row[f"{m}_median"] = np.median(z)
        row[f"{m}_gini"] = gini_coefficient(raw)
        row[f"{m}_p25"] = np.percentile(z, 25)
        row[f"{m}_p75"] = np.percentile(z, 75)

    summary_rows.append(row)


def handle_glasser_pair(subject_id, full_atlas, full_path, sub_atlas, sub_path,
                         args, metric_names, summary_rows):
    """
    Load the full Glasser matrix and its companion "*_subcortical" matrix for
    one subject, verify the subcortical block is duplicated inside the full
    matrix (bottom-right block), and if so process TWO variants ("Glasser"
    full and "Glasser_cortical" with the subcortical block dropped), leaving
    the standalone subcortical matrix aside.

    If the overlap check fails, falls back to processing both matrices
    independently and prints a warning so it can be checked manually.
    Returns True if it handled both keys (so the caller can skip them in the
    generic loop), False if it couldn't even attempt the check (e.g. load
    failure) and both should be left to the generic loop.
    """
    tag_full = f"{subject_id} / {full_atlas}"
    tag_sub = f"{subject_id} / {sub_atlas}"

    W_full = load_matrix_from_mat(full_path, var_name=args.var)
    W_sub = load_matrix_from_mat(sub_path, var_name=args.var)
    if W_full is None or W_sub is None:
        print(f"      ! could not load {tag_full} and/or {tag_sub}; "
              f"falling back to generic processing.")
        return False

    matched, max_diff = check_glasser_subcortical_overlap(W_full, W_sub)

    out_dir = os.path.dirname(full_path)

    if not matched:
        print(f"      ! {subject_id}: subcortical block does NOT match the "
              f"bottom-right {W_sub.shape[0]}x{W_sub.shape[0]} block of the "
              f"full Glasser matrix (max |diff| = {max_diff:.4g}) -> "
              f"processing both matrices independently, PLEASE CHECK MANUALLY.")
        print(f"      matrix {W_full.shape}  [{full_atlas}]")
        process_and_save(subject_id, full_atlas, W_full, out_dir, args,
                          metric_names, summary_rows)

        print(f"      matrix {W_sub.shape}  [{sub_atlas}]")
        process_and_save(subject_id, sub_atlas, W_sub, out_dir, args,
                          metric_names, summary_rows)
        return True

    print(f"      {subject_id}: confirmed the {W_sub.shape[0]}x{W_sub.shape[0]} "
          f"subcortical block is duplicated inside the full Glasser matrix "
          f"(max |diff| = {max_diff:.2g}) -> splitting into 'Glasser' (full) "
          f"and 'Glasser_cortical' (subcortical dropped); '{sub_atlas}' left aside.")

    # Variant 1: full Glasser, unchanged
    print(f"      matrix {W_full.shape}  [Glasser]")
    process_and_save(subject_id, "Glasser", W_full, out_dir, args,
                      metric_names, summary_rows)

    # Variant 2: cortical-only, subcortical rows AND columns dropped
    n_sub = W_sub.shape[0]
    W_cortical = W_full[:-n_sub, :-n_sub]
    print(f"      matrix {W_cortical.shape}  [Glasser_cortical]")
    process_and_save(subject_id, "Glasser_cortical", W_cortical, out_dir, args,
                      metric_names, summary_rows)

    return True


# -- Main pipeline -----------------------------------------------------------

def merge_summary_csv(new_rows, summary_csv):
    """
    Merge newly computed summary rows into summary_aggregates.csv instead of
    overwriting it. Both 01b_extract_fc_metrics_from_matrices.py and 01a_extract_fc_metrics_from_timeseries.py
    write to the SAME file (since they're normally pointed at the same --dir),
    and each only covers a subset of atlases (square vs rectangular inputs).
    Overwriting would silently drop whatever the other script had written.

    Rows are keyed by (subject, atlas): if a row for that pair already exists
    in the file on disk, it's replaced by the new one (so re-running a script
    is safe/idempotent); rows for subject/atlas pairs not touched by this run
    are left untouched.
    """
    new_df = pd.DataFrame(new_rows)

    if os.path.exists(summary_csv):
        old_df = pd.read_csv(summary_csv)
        # Drop old rows that are being replaced by this run's (subject, atlas)
        new_keys = set(zip(new_df["subject"], new_df["atlas"]))
        keep_mask = ~old_df.apply(
            lambda r: (r["subject"], r["atlas"]) in new_keys, axis=1)
        old_df = old_df[keep_mask]
        merged = pd.concat([old_df, new_df], ignore_index=True)
    else:
        merged = new_df

    merged = merged.sort_values(["subject", "atlas"]).reset_index(drop=True)
    merged.to_csv(summary_csv, index=False)
    return merged


def main():
    parser = argparse.ArgumentParser(
        description="Extract nodal graph metrics from pre-built FC matrices (.mat)."
    )
    parser.add_argument("--dir", required=True,
                        help="Root directory containing .mat files")
    parser.add_argument("--var", default=None,
                        help="Variable name inside each .mat (auto if omitted)")
    parser.add_argument("--neg", default="zero",
                        choices=["keep", "abs", "zero"],
                        help="How to treat negative correlations before graph "
                             "metrics (default: zero them out)")
    args = parser.parse_args()

    root_dir = args.dir
    groups = discover_mat_files(root_dir)
    subjects = sorted(set(k[0] for k in groups.keys()))
    print(f"Found {len(subjects)} subjects, {len(groups)} subject-atlas pairs.")
    print(f"Negative handling: --neg {args.neg}\n")

    metric_names = ["strength", "clustering", "betweenness", "closeness"]
    summary_rows = []

    # -- Pass 1: Glasser subcortical pairing (per subject) -----------------
    # Group atlas keys by subject so we can find, for each subject, whether
    # there's a full Glasser matrix and a matching "*_subcortical" matrix.
    by_subject = {}
    for (subj, atlas), path in groups.items():
        by_subject.setdefault(subj, {})[atlas] = path

    processed_keys = set()  # (subject, atlas) pairs already handled below

    for subject_id, atlas_map in sorted(by_subject.items()):
        glasser_full = [a for a in atlas_map
                        if is_glasser_atlas(a) and not is_subcortical_atlas(a)]
        glasser_sub = [a for a in atlas_map
                       if is_glasser_atlas(a) and is_subcortical_atlas(a)]

        if not glasser_full and not glasser_sub:
            continue  # no Glasser-like files for this subject, nothing to do

        if glasser_full and glasser_sub:
            if len(glasser_full) > 1 or len(glasser_sub) > 1:
                print(f"  ! {subject_id}: multiple Glasser-like files found "
                      f"({glasser_full + glasser_sub}); can't pair them "
                      f"automatically, processing each independently.")
                continue  # leave all of them to the generic loop below

            full_atlas, sub_atlas = glasser_full[0], glasser_sub[0]
            print(f"\n  {subject_id}: pairing '{full_atlas}' with '{sub_atlas}'...")
            handled = handle_glasser_pair(
                subject_id, full_atlas, atlas_map[full_atlas],
                sub_atlas, atlas_map[sub_atlas],
                args, metric_names, summary_rows)
            if handled:
                processed_keys.add((subject_id, full_atlas))
                processed_keys.add((subject_id, sub_atlas))

        elif glasser_sub and not glasser_full:
            print(f"  ! {subject_id}: found subcortical-only Glasser file(s) "
                  f"{glasser_sub} with no matching full Glasser file -> "
                  f"leaving aside as requested (not processed alone).")
            for a in glasser_sub:
                processed_keys.add((subject_id, a))

    # -- Pass 2: everything else, generic processing ------------------------
    for (subject_id, atlas_name), path in sorted(groups.items()):
        if (subject_id, atlas_name) in processed_keys:
            continue

        tag = f"{subject_id} / {atlas_name}"
        print(f"  Processing {tag}...")

        W = load_matrix_from_mat(path, var_name=args.var)
        if W is None:
            print(f"      skipping {tag} (could not load matrix).")
            continue

        n_reg = expected_regions(atlas_name)
        if n_reg is not None and W.shape[0] != n_reg:
            print(f"      (note: {atlas_name} matrix has {W.shape[0]} regions, "
                  f"expected {n_reg} for this atlas name -- just an FYI, not "
                  f"blocking processing)")

        print(f"      using matrix as-is {W.shape}")

        out_dir = os.path.dirname(path)
        process_and_save(subject_id, atlas_name, W, out_dir, args,
                          metric_names, summary_rows)

    # -- Save summary CSV at root level (merge, don't overwrite) --
    if summary_rows:
        summary_csv = os.path.join(root_dir, "summary_aggregates.csv")
        merged_df = merge_summary_csv(summary_rows, summary_csv)
        print(f"\nDone. Summary saved to: {summary_csv} "
              f"({len(summary_rows)} rows from this run, {len(merged_df)} total)")
        print(merged_df.to_string(index=False))
    else:
        print("\nNo data processed.")


if __name__ == "__main__":
    main()
