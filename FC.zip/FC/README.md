# Functional connectivity (FC): graph-metric extraction and statistics

Code used to extract nodal graph metrics from functional connectivity (FC)
matrices and to compare them across parcellations (Desikan, Schaefer, Glasser)
and between diagnostic groups (CN vs MCI), ADNI cohort. The same metrics and
statistical procedures are used in the structural connectivity (SC) pipeline.

The scripts are provided exactly as used for the analyses in the paper.

## Contents

| Script | Purpose |
|---|---|
| `01a_extract_fc_metrics_from_timeseries.py` | Builds FC matrices (Pearson correlation) from parcellated time series and extracts nodal metrics |
| `01b_extract_fc_metrics_from_matrices.py` | Extracts nodal metrics from FC matrices that are already built (square) |
| `02_compare_atlases.py` | Metric distributions, aggregate boxplots, pairwise KS tests, Friedman + post-hoc Wilcoxon (atlas comparison) |
| `03_report_boxplot_values.py` | Reports the numerical values (median, IQR) behind the aggregate boxplots |
| `04_group_comparison_CN_vs_MCI.py` | Node-wise CN vs MCI comparison (Mann-Whitney U, FDR, Cohen's d) and atlas sensitivity |

Run order: `01a` and `01b` (either order, same `--dir`) → `02` → `04`. Script `03` is run after `01a`/`01b`, with the same inputs as `02`.

Each `.mat` file is picked up by exactly one of the two `01` scripts: `01a` processes
rectangular arrays (regions × time points) and skips square ones, `01b` processes
square matrices and skips rectangular ones. Both can therefore be pointed at the same
folder, and both merge their results into the same `summary_aggregates.csv`.


## Installation

Python 3.9+ is recommended.

```bash
pip install -r requirements.txt
```

`h5py` is needed to read MATLAB v7.3 (HDF5) `.mat` files, which `scipy` cannot open.
The plots use the Helvetica font; if it is not installed, matplotlib falls back to its
default font and prints warnings (results are unaffected).

## Data

ADNI data cannot be redistributed. To reproduce the analyses, obtain the data from
ADNI (https://adni.loni.usc.edu) and generate the parcellated time series / FC matrices
as described in the paper. The scripts expect one folder per subject:

```
data_FC/
├── sub-002S0413/
│   ├── sub-002S0413_Desikan.mat                      # time series (regions × time)
│   ├── sub-002S0413_Schaefer100.mat                  # time series
│   ├── sub-002S0413_Glasser.mat                      # time series, 379 regions (360 cortical + 19 subcortical)
│   ├── sub-002S0413_Glasser_subcortical.mat          # time series, the 19 subcortical regions
│   ├── sub-002S0413_Desikan_subcortical_FC.mat       # pre-built square FC matrix (cortical + subcortical)
│   └── sub-002S0413_Schaefer100_subcortical_FC.mat   # pre-built square FC matrix
└── ...
```

- Folders are named `sub-<ID>` (ADNI ID without underscores, e.g. `002_S_0413` → `sub-002S0413`).
- Files are named `<subject>_<Atlas>.mat`; the part after the subject ID is the atlas name used throughout.
- `.mat` files are searched recursively under `--dir`. The variable inside the file is detected automatically (largest 2D array), or can be given with `--var`.
- Atlas names and their mapping to the unified names:

| Group | Desikan | Schaefer | Glasser |
|---|---|---|---|
| `SUBC_atlases` (with subcortical) | `Desikan_subcortical_FC` | `Schaefer100_subcortical_FC` | `Glasser` |
| `noSUBC_atlases` (cortical only) | `Desikan` | `Schaefer100` | `Glasser_cortical` |

- **Diagnostic file** (`--diag`, step 04): CSV with columns `Subject ID` (e.g. `002_S_0413`), `Visit Number`, `DIAGNOSTIC CLASS`. For each subject, the code uses the diagnosis in the row with the lowest `Visit Number` found in this file (the file contains the diagnosis at the visit used for the analysis; see the paper for how it was matched to the imaging data). Only `CN` and `MCI` are kept.
- **Subset directory** (`--subset-dir`) and `--exclude`: `--subset-dir` is a directory containing `sub-*` folders that defines the subjects shared with the SC analysis. The analyses reported in the paper use the subjects present in both `--dir` and `--subset-dir` (the common subset analysed in both SC and FC); the corresponding output files are suffixed `_shared_FC-SC`. (The scripts also write analogous files suffixed `_all`, covering every subject in `--dir`; these are not used in the paper.) `--exclude` removes specific subject IDs from this shared subset only (in our analysis, 6 subjects with FC data but not in the SC set).

## Usage

### 1. Extract metrics

```bash
# time series -> FC matrix -> metrics
python 01a_extract_fc_metrics_from_timeseries.py --dir /path/to/data_FC \
    --timepoints 197 200 976 750 951 100 194

# pre-built FC matrices -> metrics
python 01b_extract_fc_metrics_from_matrices.py --dir /path/to/data_FC
```

Processing of each matrix (identical in both scripts):

1. FC from time series (`01a` only): Pearson correlation between regions (`numpy.corrcoef`). `--timepoints` lists the valid numbers of time points and is used to decide which axis of the array is time.
2. Negative correlations are set to 0 (`--neg zero`, default; `keep` and `abs` are available). This is a methodological choice, needed because lengths are defined as 1/weight.
3. NaNs are replaced with 0, the diagonal is set to 0, and the matrix is symmetrized if needed.
4. Metrics (Brain Connectivity Toolbox, `bctpy`): strength, weighted clustering coefficient, betweenness centrality (on lengths = 1/weight), closeness centrality (inverse of the mean shortest path length).
5. Nodal metrics are z-scored across nodes within each subject/atlas.

Glasser subcortical handling: when both `Glasser` and `Glasser_subcortical` are present, the
script checks that the subcortical regions are contained in the full Glasser data. If so, it
produces `Glasser` (all 379 regions) and `Glasser_cortical` (the 360 cortical regions), and the
standalone `Glasser_subcortical` file is not processed on its own. `01a` skips this step for
subjects whose Glasser outputs already exist unless `--overwrite` is given.

Outputs (written in each subject folder): `<subject>_<Atlas>_FC.npy` (FC matrix actually used),
`<subject>_<Atlas>_nodal_metrics.csv` (raw and z-scored metrics, `*_z`). In `--dir`:
`summary_aggregates.csv` (per subject/atlas: median, 25th and 75th percentile of the z-scored
metrics; Gini coefficient of the raw metrics), merged across runs.

### 2. Atlas comparison

```bash
python 02_compare_atlases.py \
    --input /path/to/data_FC \
    --plots /path/to/results/02_compare_atlases \
    --subset-dir /path/to/shared_subjects_dir \
    --exclude sub-AAAAAAA sub-BBBBBBB
```

Outputs, in `SUBC_atlases/` and `noSUBC_atlases/`, (files suffixed `_shared_FC-SC`):
density plots of z-scored metrics, aggregate boxplots (median and Gini), pairwise
Kolmogorov-Smirnov tests (heatmaps + CSV), Friedman test and post-hoc Wilcoxon signed-rank
tests (FDR-corrected, Benjamini-Hochberg). Aggregates are recomputed from the nodal CSV files,
not read from `summary_aggregates.csv`.

To print the numbers underlying the aggregate boxplots:

```bash
python 03_report_boxplot_values.py \
    --input /path/to/data_FC \
    --subset-dir /path/to/shared_subjects_dir \
    --exclude sub-AAAAAAA sub-BBBBBBB \
    --out /path/to/results/boxplot_values.csv
```

### 3. CN vs MCI group comparison

```bash
python 04_group_comparison_CN_vs_MCI.py \
    --dir /path/to/data_FC \
    --diag /path/to/longitudinal_ADNI_filtering_FINAL.csv \
    --plots /path/to/results/04_group_comparison \
    --subset-dir /path/to/shared_subjects_dir \
    --exclude sub-AAAAAAA sub-BBBBBBB
```

Uses the z-scored metrics. Node-wise Mann-Whitney U tests (CN vs MCI) with FDR correction and
Cohen's d, atlas sensitivity (percentage of significant nodes, effect sizes) and a list of
significant nodes, in `SUBC_atlases/` and `noSUBC_atlases/` (files suffixed `_shared_FC-SC`).

## Notes

- `--subset-dir` and `--exclude` are optional; without `--subset-dir` the `shared_FC-SC` results are not produced.
- Statistical tests use the z-scored metrics (`*_z`).
