"""
Script 1a (TS version): Build FC matrices from time series and extract nodal
graph metrics.

Reads .mat files that contain parcellated time series (regions x time,
RECTANGULAR only) and builds a functional connectivity matrix by
Pearson-correlating the regions.

This script ONLY processes rectangular (time series) inputs. If a .mat file
turns out to already hold a square matrix, it is SKIPPED (with a message
pointing to 01b_extract_fc_metrics_from_matrices.py, the companion script for already-built
matrices) -- the subject/atlas isn't silently mishandled, it's simply not
this script's job. This means the two scripts can safely be pointed at the
same folder containing a mix of time-series and pre-built-matrix .mat files:
each script will only pick up the files that are actually its job, and skip
the rest with an explicit message.

Notes on the generation steps:
  * Orientation is handled so regions always end up on the rows before
    correlating. Use --timepoints (recommended, accepts one or more valid
    values e.g. --timepoints 197 200) to identify the time axis
    unambiguously; orientation also falls back to known atlas region counts.
  * Correlation matrices contain NEGATIVE values (anticorrelations). The 1/W
    "length" conversion used for betweenness/closeness assumes W >= 0, so
    negatives are handled via --neg (default: set to 0). THIS IS A
    METHODOLOGICAL CHOICE -- confirm it matches your analysis.

Glasser subcortical handling:
  Glasser data may come as a full file (379 regions = 360 cortical + 19
  subcortical) plus a separate "*_Glasser_subcortical" file duplicating just
  the 19 subcortical regions. For each subject, before normal processing,
  the script checks whether those 19 rows are indeed contained (duplicated)
  in the full Glasser file. If confirmed:
    - "Glasser"          -> the full 379-region file, processed as-is
    - "Glasser_cortical" -> the same data with the last 19 (subcortical)
                             rows dropped (379 - 19 = 360 regions)
    - the standalone "*_Glasser_subcortical" file itself is left aside and
      NOT processed on its own (it only served to verify/derive the above).
  If the check fails (rows don't match), both files are processed
  independently as before and a warning is printed so it can be checked
  manually. Desikan and Schaefer are unaffected by any of this. If either
  matrix in the pair turns out to be square (not a time series), the pairing
  is skipped here too, with the usual "use -MAT instead" message.

Usage:
  python 01a_extract_fc_metrics_from_timeseries.py --dir /path/to/data/FC_matrices --timepoints 197 200
  python 01a_extract_fc_metrics_from_timeseries.py --dir /path/to/data --var ts --neg abs
"""

import os
import re
import argparse
import numpy as np
import pandas as pd
import bct
from scipy.io import loadmat

try:
    import h5py
    _HAS_H5PY = True
except ImportError:
    _HAS_H5PY = False


# Known region counts per atlas, used to orient time series if --timepoints
# is not enough. Add/adjust entries if you use other atlases or resolutions.
ATLAS_REGIONS = {
    "desikan": 70,
    "glasser": 379,
    "schaefer": 100,
}

# Glasser-specific region counts, used only by the subcortical-split logic
# below (kept separate from ATLAS_REGIONS so the generic substring lookup in
# expected_regions() isn't confused by "glasser_subcortical" also containing
# "glasser").
GLASSER_TOTAL_REGIONS = 379
GLASSER_SUBCORTICAL_REGIONS = 19
GLASSER_CORTICAL_REGIONS = GLASSER_TOTAL_REGIONS - GLASSER_SUBCORTICAL_REGIONS  # 360


# -- Helpers -----------------------------------------------------------------

def gini_coefficient(values):
    """Compute Gini coefficient for a 1D array of non-negative values."""
    v = np.sort(np.abs(values))
    n = len(v)
    if n == 0 or v.sum() == 0:
        return 0.0
    index = np.arange(1, n + 1)
    return (2 * np.sum(index * v) - (n + 1) * np.sum(v)) / (n * np.sum(v))


def zscore(v):
    """Z-score a vector. Returns zeros if std is 0."""
    std = np.std(v, ddof=1)
    if std == 0:
        return np.zeros_like(v)
    return (v - np.mean(v)) / std


# -- Loading -----------------------------------------------------------------

def _load_2d_array_scipy(path, var_name=None):
    """Load a 2D array from a classic (< v7.3) .mat file via scipy."""
    mat = loadmat(path)
    user_keys = [k for k in mat if not k.startswith("__")]

    if var_name is not None:
        if var_name not in mat:
            print(f"      ! variable '{var_name}' not in file; "
                  f"available: {user_keys}")
            return None
        return np.asarray(mat[var_name], dtype=float)

    candidates = []
    for k in user_keys:
        v = np.asarray(mat[k])
        if v.ndim == 2 and min(v.shape) > 1:
            candidates.append((v.size, k))
    if not candidates:
        print(f"      ! no 2D array found; available: {user_keys}")
        return None

    candidates.sort()
    chosen = candidates[-1][1]
    if len(candidates) > 1:
        print(f"      (auto-selected variable '{chosen}' from {user_keys})")
    return np.asarray(mat[chosen], dtype=float)


def _load_2d_array_h5py(path, var_name=None):
    """Load a 2D array from a MATLAB v7.3 (HDF5) .mat file via h5py."""
    if not _HAS_H5PY:
        print(f"      ! {path}: this looks like a MATLAB v7.3/HDF5 file, "
              f"but h5py is not installed. Run: pip install h5py")
        return None

    with h5py.File(path, "r") as f:
        user_keys = [k for k in f.keys() if not k.startswith("#")]

        if var_name is not None:
            if var_name not in f:
                print(f"      ! variable '{var_name}' not in file; "
                      f"available: {user_keys}")
                return None
            return np.asarray(f[var_name], dtype=float)

        candidates = []
        for k in user_keys:
            item = f[k]
            if isinstance(item, h5py.Dataset) and item.ndim == 2 and min(item.shape) > 1:
                candidates.append((item.size, k))
        if not candidates:
            print(f"      ! no 2D dataset found; available: {user_keys}")
            return None

        candidates.sort()
        chosen = candidates[-1][1]
        if len(candidates) > 1:
            print(f"      (auto-selected variable '{chosen}' from {user_keys})")
        return np.asarray(f[chosen], dtype=float)


def load_2d_array_from_mat(path, var_name=None):
    """
    Load a 2D numeric array from a .mat file, transparently handling both
    classic and v7.3/HDF5 formats (falls back to h5py when scipy can't read
    the file). Accepts rectangular arrays (time series) as well as square
    ones (matrices, which the caller will then skip -- see main()). Returns
    an ndarray or None.
    """
    try:
        return _load_2d_array_scipy(path, var_name=var_name)
    except NotImplementedError:
        # scipy raises this specifically for v7.3/HDF5 files -- fall back.
        return _load_2d_array_h5py(path, var_name=var_name)


# -- FC generation (NEW) -----------------------------------------------------

def expected_regions(atlas_name):
    """Look up the expected region count for an atlas name (substring match)."""
    a = atlas_name.lower()
    for key, n in ATLAS_REGIONS.items():
        if key in a:
            return n
    return None


def orient_timeseries(A, atlas_name, n_timepoints=None):
    """
    Return the time series oriented as (regions x time), transposing if needed.

    n_timepoints can be a single int, a list/tuple/set of valid values (e.g.
    [197, 200] if different acquisitions have different lengths), or None.

    Priority: (1) the axis whose length is one of the valid n_timepoints
    values is the time axis; (2) the axis matching the atlas's known region
    count is the region axis; (3) fallback assumes rows are already regions
    (with a warning).
    """
    r, c = A.shape

    if n_timepoints is not None:
        valid_tp = {n_timepoints} if isinstance(n_timepoints, int) else set(n_timepoints)
        if c in valid_tp and r not in valid_tp:
            return A
        if r in valid_tp and c not in valid_tp:
            return A.T

    n_reg = expected_regions(atlas_name)
    if n_reg is not None:
        if r == n_reg:
            return A
        if c == n_reg:
            return A.T

    print(f"      ! orientation uncertain for shape {A.shape} -> assuming "
          f"rows = regions (pass --timepoints to fix)")
    return A


def timeseries_to_fc(ts):
    """Build a functional connectivity matrix (Pearson r) from regions x time."""
    return np.corrcoef(ts)


# -- Glasser subcortical pairing (NEW) ---------------------------------------

def is_glasser_atlas(atlas_name):
    return "glasser" in atlas_name.lower()


def is_subcortical_atlas(atlas_name):
    return "subcortical" in atlas_name.lower()


def check_glasser_subcortical_overlap(ts_full, ts_sub, atol=1e-6, rtol=1e-5):
    """
    Check whether ts_sub (subcortical-only time series, n_sub x time) is
    contained as the LAST n_sub rows of ts_full (n_full x time, oriented as
    regions x time). Returns (matched: bool, max_abs_diff: float).
    """
    n_sub = ts_sub.shape[0]
    if ts_full.shape[0] < n_sub or ts_full.shape[1] != ts_sub.shape[1]:
        return False, np.inf

    tail = ts_full[-n_sub:, :]
    matched = np.allclose(tail, ts_sub, atol=atol, rtol=rtol)
    max_diff = float(np.max(np.abs(tail - ts_sub)))
    return matched, max_diff


def handle_negatives(W, mode):
    """Deal with negative weights before graph metrics. mode: keep|abs|zero."""
    if mode == "keep":
        return W
    if mode == "abs":
        return np.abs(W)
    if mode == "zero":
        return np.where(W < 0, 0.0, W)
    raise ValueError(f"unknown --neg mode: {mode}")


# -- Sanitizing --------------------------------------------------------------

def sanitize_matrix(W, tag):
    """
    Standard cleanups for BCT undirected/weighted metrics: drop NaNs, zero the
    diagonal, symmetrize, and warn about leftover negative weights.
    """
    W = np.asarray(W, dtype=float)

    if np.isnan(W).any():
        print(f"      ! {tag}: matrix contains NaNs -> replaced with 0")
        W = np.nan_to_num(W, nan=0.0)

    if not np.allclose(np.diag(W), 0):
        np.fill_diagonal(W, 0.0)

    asym = float(np.max(np.abs(W - W.T)))
    if asym > 1e-8:
        print(f"      ! {tag}: SYMMETRIZE APPLIED -> max |W - W.T| = {asym:.2e} "
              f"(values near 1e-10 are rounding noise; large values mean the "
              f"input was not a valid undirected matrix, check it)")
        W = (W + W.T) / 2.0

    if (W < 0).any():
        print(f"      ! {tag}: matrix still has NEGATIVE weights -> betweenness/"
              f"closeness will be unreliable (length = 1/W assumes W >= 0)")

    return W


# -- Metric extraction (unchanged) -------------------------------------------

def compute_metrics(W):
    """Compute 4 nodal metrics from a weighted undirected connectivity matrix."""

    strength = bct.strengths_und(W)
    clustering = bct.clustering_coef_wu(W)

    D = bct.weight_conversion(W, "lengths")
    betweenness = bct.betweenness_wei(D)

    shortest_paths = bct.distance_wei(D)[0]
    np.fill_diagonal(shortest_paths, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        mean_sp = np.nanmean(shortest_paths, axis=1)
        closeness = np.where(mean_sp > 0, 1.0 / mean_sp, 0.0)

    return {
        "strength": strength,
        "clustering": clustering,
        "betweenness": betweenness,
        "closeness": closeness,
    }


# -- File parsing / discovery ------------------------------------------------

def parse_filename(fname):
    """
    Parse a .mat filename into (subject_id, atlas_name).
    Expects names like 'sub-002S0413_Desikan_FC.mat'.
    """
    stem = fname[:-4] if fname.lower().endswith(".mat") else fname
    match = re.match(r"(sub-[^_]+)_(.+)", stem)
    if match:
        return match.group(1), match.group(2)
    return stem, "atlas"


def discover_mat_files(root_dir):
    """Recursively find all .mat files, keyed by (subject, atlas)."""
    groups = {}
    for dirpath, _, filenames in os.walk(root_dir):
        for fname in sorted(filenames):
            if not fname.lower().endswith(".mat"):
                continue
            key = parse_filename(fname)
            if key in groups:
                print(f"  ! duplicate key {key}: ignoring "
                      f"{os.path.join(dirpath, fname)}")
                continue
            groups[key] = os.path.join(dirpath, fname)
    return groups


def outputs_exist(subject_id, atlas_name, out_dir):
    """Check whether the .npy and .csv outputs for this subject/atlas were
    already written by a previous (possibly interrupted) run."""
    npy_path = os.path.join(out_dir, f"{subject_id}_{atlas_name}_FC.npy")
    csv_path = os.path.join(
        out_dir, f"{subject_id}_{atlas_name}_nodal_metrics.csv")
    return os.path.exists(npy_path) and os.path.exists(csv_path)


def summary_row_from_existing_csv(subject_id, atlas_name, out_dir, metric_names):
    """
    Recompute the aggregate summary row (same formulas as process_and_save)
    directly from an already-saved *_nodal_metrics.csv, instead of redoing
    the expensive matrix/correlation work. Used when Glasser pairing is
    skipped because outputs already exist -- without this, summary_rows
    would simply never get a Glasser/Glasser_cortical entry for that run,
    and summary_aggregates.csv would end up permanently missing them.
    Returns None if the CSV can't be read/is missing expected columns.
    """
    csv_path = os.path.join(
        out_dir, f"{subject_id}_{atlas_name}_nodal_metrics.csv")
    try:
        node_df = pd.read_csv(csv_path)
    except Exception as e:
        print(f"      ! could not read {csv_path} to rebuild summary row: {e}")
        return None

    row = {"subject": subject_id, "atlas": atlas_name, "n_nodes": len(node_df)}
    for m in metric_names:
        z_col, raw_col = f"{m}_z", m
        if z_col not in node_df.columns or raw_col not in node_df.columns:
            print(f"      ! {csv_path} missing column '{z_col}' or '{raw_col}'; "
                  f"skipping summary row for this atlas.")
            return None
        z = node_df[z_col].values
        raw = node_df[raw_col].values
        row[f"{m}_median"] = np.median(z)
        row[f"{m}_gini"] = gini_coefficient(raw)
        row[f"{m}_p25"] = np.percentile(z, 25)
        row[f"{m}_p75"] = np.percentile(z, 75)

    return row


# -- Shared per-matrix processing (steps 5-8, unchanged logic) --------------

def process_and_save(subject_id, atlas_name, W, out_dir, args,
                      metric_names, summary_rows):
    """
    Given an already-built (or already-square) connectivity matrix W, run the
    same negative-handling/sanitize/metrics/save steps used for every atlas,
    and append a summary row. Shared by the normal loop and the Glasser
    subcortical-split routine so the logic isn't duplicated.
    """
    tag = f"{subject_id} / {atlas_name}"

    # -- 5. Handle negatives, then 6. sanitize --
    W = handle_negatives(W, args.neg)
    W = sanitize_matrix(W, tag)

    # Save the generated FC matrix so it can be inspected/reused.
    np.save(os.path.join(out_dir, f"{subject_id}_{atlas_name}_FC.npy"), W)

    n_nodes = W.shape[0]
    metrics = compute_metrics(W)

    # -- 7. Build nodal CSV (raw + z-scored) --
    node_data = {"node_index": np.arange(n_nodes)}
    for m in metric_names:
        node_data[m] = metrics[m]
        node_data[f"{m}_z"] = zscore(metrics[m])

    node_df = pd.DataFrame(node_data)
    node_csv = os.path.join(
        out_dir, f"{subject_id}_{atlas_name}_nodal_metrics.csv")
    node_df.to_csv(node_csv, index=False)

    # -- 8. Compute aggregates --
    row = {"subject": subject_id, "atlas": atlas_name, "n_nodes": n_nodes}
    for m in metric_names:
        z = node_data[f"{m}_z"]
        raw = metrics[m]
        row[f"{m}_median"] = np.median(z)
        row[f"{m}_gini"] = gini_coefficient(raw)
        row[f"{m}_p25"] = np.percentile(z, 25)
        row[f"{m}_p75"] = np.percentile(z, 75)

    summary_rows.append(row)


def handle_glasser_pair(subject_id, full_atlas, full_path, sub_atlas, sub_path,
                         args, metric_names, summary_rows):
    """
    Load the full Glasser file and its companion "*_subcortical" file for one
    subject, verify the subcortical rows are duplicated inside the full file,
    and if so process TWO variants ("Glasser" 379-region and "Glasser_cortical"
    360-region), leaving the standalone subcortical file aside.

    If the overlap check fails, falls back to processing both files
    independently (same as the generic loop would have done) and prints a
    warning so it can be checked manually. Returns True if it handled both
    keys (so the caller can skip them in the generic loop), False if it
    couldn't even attempt the check (e.g. load failure) and both should be
    left to the generic loop.
    """
    tag_full = f"{subject_id} / {full_atlas}"
    tag_sub = f"{subject_id} / {sub_atlas}"

    out_dir = os.path.dirname(full_path)
    if not args.overwrite and outputs_exist(subject_id, "Glasser", out_dir) \
            and outputs_exist(subject_id, "Glasser_cortical", out_dir):
        print(f"      Skipping {subject_id} Glasser pairing: 'Glasser' and "
              f"'Glasser_cortical' outputs already exist (use --overwrite "
              f"to force recompute). Rebuilding their summary rows from the "
              f"existing nodal CSVs so summary_aggregates.csv stays complete.")
        for a in ("Glasser", "Glasser_cortical"):
            row = summary_row_from_existing_csv(subject_id, a, out_dir, metric_names)
            if row is not None:
                summary_rows.append(row)
        return True

    A_full = load_2d_array_from_mat(full_path, var_name=args.var)
    A_sub = load_2d_array_from_mat(sub_path, var_name=args.var)
    if A_full is None or A_sub is None:
        print(f"      ! could not load {tag_full} and/or {tag_sub}; "
              f"falling back to generic processing.")
        return False

    # This script only pairs TIME SERIES (rectangular). If either file is
    # already a square matrix, this pairing doesn't apply here -- let the
    # generic loop skip it with the proper message (use -MAT instead).
    if A_full.shape[0] == A_full.shape[1] or A_sub.shape[0] == A_sub.shape[1]:
        print(f"      ! {subject_id}: '{full_atlas}' or '{sub_atlas}' is a "
              f"square matrix, not a time series -> skipping this pairing "
              f"here (use 01b_extract_fc_metrics_from_matrices.py for square inputs).")
        return False

    ts_full = orient_timeseries(A_full, full_atlas, args.timepoints)
    ts_sub = orient_timeseries(A_sub, sub_atlas, args.timepoints)

    matched, max_diff = check_glasser_subcortical_overlap(ts_full, ts_sub)

    out_dir = os.path.dirname(full_path)

    if not matched:
        print(f"      ! {subject_id}: subcortical rows do NOT match the last "
              f"{ts_sub.shape[0]} rows of the full Glasser file "
              f"(max |diff| = {max_diff:.4g}) -> processing both files "
              f"independently, PLEASE CHECK MANUALLY.")
        W_full = timeseries_to_fc(ts_full)
        print(f"      time series {A_full.shape} -> FC {W_full.shape}  [{full_atlas}]")
        process_and_save(subject_id, full_atlas, W_full, out_dir, args,
                          metric_names, summary_rows)

        W_sub = timeseries_to_fc(ts_sub)
        print(f"      time series {A_sub.shape} -> FC {W_sub.shape}  [{sub_atlas}]")
        process_and_save(subject_id, sub_atlas, W_sub, out_dir, args,
                          metric_names, summary_rows)
        return True

    print(f"      {subject_id}: confirmed the {ts_sub.shape[0]} subcortical "
          f"rows are duplicated inside the full Glasser file (max |diff| = "
          f"{max_diff:.2g}) -> splitting into 'Glasser' (full) and "
          f"'Glasser_cortical' (subcortical dropped); '{sub_atlas}' left aside.")

    # Variant 1: full Glasser, unchanged
    W_full = timeseries_to_fc(ts_full)
    print(f"      time series {ts_full.shape} -> FC {W_full.shape}  [Glasser]")
    process_and_save(subject_id, "Glasser", W_full, out_dir, args,
                      metric_names, summary_rows)

    # Variant 2: cortical-only, subcortical rows dropped
    n_sub = ts_sub.shape[0]
    ts_cortical = ts_full[:-n_sub, :]
    W_cortical = timeseries_to_fc(ts_cortical)
    print(f"      time series {ts_cortical.shape} -> FC {W_cortical.shape}  "
          f"[Glasser_cortical]")
    process_and_save(subject_id, "Glasser_cortical", W_cortical, out_dir, args,
                      metric_names, summary_rows)

    return True


# -- Main pipeline -----------------------------------------------------------

def merge_summary_csv(new_rows, summary_csv):
    """
    Merge newly computed summary rows into summary_aggregates.csv instead of
    overwriting it. Both 01b_extract_fc_metrics_from_matrices.py and 01a_extract_fc_metrics_from_timeseries.py
    write to the SAME file (since they're normally pointed at the same --dir),
    and each only covers a subset of atlases (square vs rectangular inputs).
    Overwriting would silently drop whatever the other script had written.

    Rows are keyed by (subject, atlas): if a row for that pair already exists
    in the file on disk, it's replaced by the new one (so re-running a script
    is safe/idempotent); rows for subject/atlas pairs not touched by this run
    are left untouched.
    """
    new_df = pd.DataFrame(new_rows)

    if os.path.exists(summary_csv):
        old_df = pd.read_csv(summary_csv)
        new_keys = set(zip(new_df["subject"], new_df["atlas"]))
        keep_mask = ~old_df.apply(
            lambda r: (r["subject"], r["atlas"]) in new_keys, axis=1)
        old_df = old_df[keep_mask]
        merged = pd.concat([old_df, new_df], ignore_index=True)
    else:
        merged = new_df

    merged = merged.sort_values(["subject", "atlas"]).reset_index(drop=True)
    merged.to_csv(summary_csv, index=False)
    return merged


def main():
    parser = argparse.ArgumentParser(
        description="Generate FC matrices and extract nodal graph metrics."
    )
    parser.add_argument("--dir", required=True,
                        help="Root directory containing .mat files")
    parser.add_argument("--var", default=None,
                        help="Variable name inside each .mat (auto if omitted)")
    parser.add_argument("--timepoints", type=int, default=None, nargs="+",
                        help="Number(s) of fMRI timepoints (e.g. --timepoints "
                             "197 200 if acquisitions can have either length), "
                             "used to orient time series unambiguously")
    parser.add_argument("--neg", default="zero",
                        choices=["keep", "abs", "zero"],
                        help="How to treat negative correlations before graph "
                             "metrics (default: zero them out)")
    parser.add_argument("--overwrite", action="store_true",
                        help="Recompute and overwrite the Glasser/Glasser_cortical "
                             "outputs even if they already exist (this only "
                             "applies to the Glasser pairing step -- Desikan/"
                             "Schaefer100 etc. are always reprocessed)")
    args = parser.parse_args()

    root_dir = args.dir
    groups = discover_mat_files(root_dir)
    subjects = sorted(set(k[0] for k in groups.keys()))
    print(f"Found {len(subjects)} subjects, {len(groups)} subject-atlas pairs.")
    print(f"Negative handling: --neg {args.neg}\n")

    metric_names = ["strength", "clustering", "betweenness", "closeness"]
    summary_rows = []

    # -- Pass 1: Glasser subcortical pairing (per subject) -----------------
    # Group atlas keys by subject so we can find, for each subject, whether
    # there's a full Glasser file and a matching "*_subcortical" file.
    by_subject = {}
    for (subj, atlas), path in groups.items():
        by_subject.setdefault(subj, {})[atlas] = path

    processed_keys = set()  # (subject, atlas) pairs already handled below

    for subject_id, atlas_map in sorted(by_subject.items()):
        glasser_full = [a for a in atlas_map
                        if is_glasser_atlas(a) and not is_subcortical_atlas(a)]
        glasser_sub = [a for a in atlas_map
                       if is_glasser_atlas(a) and is_subcortical_atlas(a)]

        if not glasser_full and not glasser_sub:
            continue  # no Glasser-like files for this subject, nothing to do

        if glasser_full and glasser_sub:
            if len(glasser_full) > 1 or len(glasser_sub) > 1:
                print(f"  ! {subject_id}: multiple Glasser-like files found "
                      f"({glasser_full + glasser_sub}); can't pair them "
                      f"automatically, processing each independently.")
                continue  # leave all of them to the generic loop below

            full_atlas, sub_atlas = glasser_full[0], glasser_sub[0]
            print(f"\n  {subject_id}: pairing '{full_atlas}' with '{sub_atlas}'...")
            handled = handle_glasser_pair(
                subject_id, full_atlas, atlas_map[full_atlas],
                sub_atlas, atlas_map[sub_atlas],
                args, metric_names, summary_rows)
            if handled:
                processed_keys.add((subject_id, full_atlas))
                processed_keys.add((subject_id, sub_atlas))

        elif glasser_sub and not glasser_full:
            print(f"  ! {subject_id}: found subcortical-only Glasser file(s) "
                  f"{glasser_sub} with no matching full Glasser file -> "
                  f"leaving aside as requested (not processed alone).")
            for a in glasser_sub:
                processed_keys.add((subject_id, a))

    # -- Pass 2: everything else, generic processing (always reprocessed --
    #    the resume/skip-if-exists behavior only applies to Glasser pairing) --
    for (subject_id, atlas_name), path in sorted(groups.items()):
        if (subject_id, atlas_name) in processed_keys:
            continue

        tag = f"{subject_id} / {atlas_name}"
        out_dir = os.path.dirname(path)

        print(f"  Processing {tag}...")

        # -- 1. Load the 2D array from the .mat --
        A = load_2d_array_from_mat(path, var_name=args.var)
        if A is None:
            print(f"      skipping {tag} (could not load array).")
            continue

        # -- 2. This script only handles TIME SERIES (rectangular). Square
        #       inputs are already-built matrices -- skip them here, they
        #       belong to the -MAT script instead.
        if A.shape[0] == A.shape[1]:
            print(f"      skipping {tag}: input is square ({A.shape}) -> "
                  f"looks like an already-built matrix, not a time series. "
                  f"Use 01b_extract_fc_metrics_from_matrices.py for this file instead.")
            continue

        # -- 3-4. Build the FC matrix --
        ts = orient_timeseries(A, atlas_name, args.timepoints)
        W = timeseries_to_fc(ts)
        print(f"      time series {A.shape} -> FC {W.shape}")

        process_and_save(subject_id, atlas_name, W, out_dir, args,
                          metric_names, summary_rows)

    # -- Save summary CSV at root level (merge, don't overwrite) --
    if summary_rows:
        summary_csv = os.path.join(root_dir, "summary_aggregates.csv")
        merged_df = merge_summary_csv(summary_rows, summary_csv)
        print(f"\nDone. Summary saved to: {summary_csv} "
              f"({len(summary_rows)} rows from this run, {len(merged_df)} total)")
        print(merged_df.to_string(index=False))
    else:
        print("\nNo data processed.")


if __name__ == "__main__":
    main()
