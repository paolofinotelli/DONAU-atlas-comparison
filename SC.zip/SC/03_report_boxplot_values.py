"""
Script 3: Report the summary values underlying the aggregate boxplots
(median across subjects of each per-subject median/Gini), for the FC-shared
subset, matching the exact filtering logic of
02_compare_atlases.py.

This does NOT recompute anything from raw nodal data — it reads
summary_aggregates.csv (same as the plotting script) and applies the same
subject filtering (intersection with --subset-dir), atlas renaming, and
atlas grouping (SUBC / noSUBC). It then reports, per atlas group and metric,
the value each boxplot box is centered on (i.e. the median of the
per-subject median_/gini_ columns) plus IQR, so you can quote exact numbers
in the text instead of reading them off the plot.

Usage:
  python 03_report_boxplot_values.py --input /path/to/data_SC \
      --subset-dir /path/to/FC_data \
      --out /path/to/results/boxplot_medians.csv
"""

import os
import argparse
import pandas as pd

METRIC_NAMES = ["strength", "clustering", "betweenness", "closeness"]

# Same atlas grouping/renaming as the plotting script
SUBC_ATLAS_MAP = {"DKT": "Desikan", "FC-Schaefer2018": "Schaefer", "FC-Glasser": "Glasser"}
noSUBC_ATLAS_MAP = {"FC-Desikan": "Desikan", "Schaefer2018": "Schaefer", "glasser360MNI": "Glasser"}

ATLAS_GROUPS = {
    "SUBC_atlases": SUBC_ATLAS_MAP,
    "noSUBC_atlases": noSUBC_ATLAS_MAP,
}


def get_subject_ids(directory):
    return {n for n in os.listdir(directory)
            if n.startswith("sub-") and os.path.isdir(os.path.join(directory, n))}


def filter_and_rename_summary(summary_df, atlas_map):
    filtered = summary_df[summary_df["atlas"].isin(atlas_map.keys())].copy()
    filtered["atlas"] = filtered["atlas"].map(atlas_map)
    return filtered


def summarize(summary_df, group_name, tag):
    rows = []
    atlases = sorted(summary_df["atlas"].unique())
    for atlas in atlases:
        sub = summary_df[summary_df["atlas"] == atlas]
        for metric in METRIC_NAMES:
            for stat_type in ["median", "gini"]:
                col = f"{metric}_{stat_type}"
                if col not in sub.columns:
                    continue
                vals = sub[col].dropna()
                if len(vals) == 0:
                    continue
                q25 = vals.quantile(0.25)
                q75 = vals.quantile(0.75)
                rows.append({
                    "atlas_group": group_name,
                    "subset": tag,
                    "atlas": atlas,
                    "metric": metric,
                    "stat_type": stat_type,
                    "n_subjects": len(vals),
                    "median": round(vals.median(), 4),
                    "q25": round(q25, 4),
                    "q75": round(q75, 4),
                    "iqr_range": round(q75 - q25, 4),
                    "mean": round(vals.mean(), 4),
                    "std": round(vals.std(), 4),
                })
    return rows


def main():
    parser = argparse.ArgumentParser(
        description="Report boxplot-underlying median/Gini values for the FC-shared subset."
    )
    parser.add_argument("--input", required=True,
                         help="Root data directory containing summary_aggregates.csv "
                              "(same --input as the plotting script)")
    parser.add_argument("--subset-dir", required=True,
                         help="Directory with subject folders defining the FC-shared subset "
                              "(same --subset-dir as the plotting script)")
    parser.add_argument("--out", required=True,
                         help="Path to save the resulting summary CSV")
    args = parser.parse_args()

    summary_path = os.path.join(args.input, "summary_aggregates.csv")
    if not os.path.exists(summary_path):
        raise FileNotFoundError(f"Could not find {summary_path}")
    summary_df = pd.read_csv(summary_path)

    fc_subjects = get_subject_ids(args.subset_dir)
    all_subjects = set(summary_df["subject"].unique())
    shared_subjects = all_subjects & fc_subjects
    if not shared_subjects:
        raise RuntimeError(f"No overlapping subjects found with {args.subset_dir}")
    print(f"Found {len(shared_subjects)} shared subjects with FC group "
          f"(out of {len(all_subjects)} total in summary_aggregates.csv).")

    all_rows = []
    for group_name, atlas_map in ATLAS_GROUPS.items():
        group_summary = filter_and_rename_summary(summary_df, atlas_map)

        # Full population (tag="all")
        all_rows.extend(summarize(group_summary, group_name, tag="all"))

        # FC-shared subset (tag="shared_FC-SC") -- this matches the
        # aggregates_boxplots_shared_FC-SC.pdf values
        shared_summary = group_summary[group_summary["subject"].isin(shared_subjects)]
        if not shared_summary.empty:
            all_rows.extend(summarize(shared_summary, group_name, tag="shared_FC-SC"))
        else:
            print(f"  Warning: no shared-subset rows for {group_name}")

    out_df = pd.DataFrame(all_rows)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    out_df.to_csv(args.out, index=False)
    print(f"Saved: {args.out}")

    # Print a quick readable summary for the shared_FC-SC / noSUBC_atlases
    # group, since that's what the "FC subset" boxplot (Figure) shows.
    focus = out_df[(out_df["subset"] == "shared_FC-SC") &
                    (out_df["atlas_group"] == "noSUBC_atlases")]
    if not focus.empty:
        print("\n--- noSUBC_atlases, shared_FC-SC (matches the FC-subset boxplot) ---")
        for _, r in focus.sort_values(["metric", "stat_type", "atlas"]).iterrows():
            print(f"{r['metric']:12s} {r['stat_type']:7s} {r['atlas']:8s} "
                  f"median={r['median']:.3f}  IQR=[{r['q25']:.3f}, {r['q75']:.3f}] "
                  f"(range={r['iqr_range']:.3f})  n={r['n_subjects']}")


if __name__ == "__main__":
    main()
