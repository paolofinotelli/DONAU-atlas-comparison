"""
Script 1: Extract and normalize nodal graph metrics.

Reads .npy files from subject subfolders (one folder per subject, see README),
computes metrics, z-score normalizes, and saves results back into each folder.

Usage:
  python 01_extract_graph_metrics.py --dir /path/to/data
"""

import os
import re
import argparse
import numpy as np
import pandas as pd
import bct


# ── Helpers ────────────────────────────────────────────────────────────────

def gini_coefficient(values):
    """Compute Gini coefficient for a 1D array of non-negative values."""
    v = np.sort(np.abs(values))
    n = len(v)
    if n == 0 or v.sum() == 0:
        return 0.0
    index = np.arange(1, n + 1)
    return (2 * np.sum(index * v) - (n + 1) * np.sum(v)) / (n * np.sum(v))


def zscore(v):
    """Z-score a vector. Returns zeros if std is 0."""
    std = np.std(v, ddof=1)
    if std == 0:
        return np.zeros_like(v)
    return (v - np.mean(v)) / std


# ── Metric extraction ──────────────────────────────────────────────────────

def compute_metrics(W):
    """Compute 4 nodal metrics from a weighted undirected connectivity matrix."""

    strength = bct.strengths_und(W)
    clustering = bct.clustering_coef_wu(W)

    D = bct.weight_conversion(W, "lengths")
    betweenness = bct.betweenness_wei(D)

    shortest_paths = bct.distance_wei(D)[0]
    np.fill_diagonal(shortest_paths, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        mean_sp = np.nanmean(shortest_paths, axis=1)
        closeness = np.where(mean_sp > 0, 1.0 / mean_sp, 0.0)

    return {
        "strength": strength,
        "clustering": clustering,
        "betweenness": betweenness,
        "closeness": closeness,
    }


# ── File parsing ───────────────────────────────────────────────────────────

def parse_filename(fname):
    """
    Parse 'sub-002S0413_FC-Glasser_length.npy' into components.
    Returns (subject_id, atlas_name, is_length).
    """
    stem = fname.replace(".npy", "")
    is_length = stem.endswith("_length")
    if is_length:
        stem = stem.rsplit("_length", 1)[0]

    match = re.match(r"(sub-[^_]+)_(.+)", stem)
    if not match:
        return None, None, None

    return match.group(1), match.group(2), is_length


def discover_files_in_subject_folders(root_dir):
    """
    Walk subject subfolders and group .npy files by (subject, atlas).
    Returns dict: {(subject, atlas): {"matrix": path, "length": path}}
    """
    groups = {}

    for subj_folder in sorted(os.listdir(root_dir)):
        subj_path = os.path.join(root_dir, subj_folder)
        if not os.path.isdir(subj_path) or not subj_folder.startswith("sub-"):
            continue

        for fname in sorted(os.listdir(subj_path)):
            if not fname.endswith(".npy"):
                continue

            subject_id, atlas_name, is_length = parse_filename(fname)
            if subject_id is None:
                continue

            key = (subject_id, atlas_name)
            if key not in groups:
                groups[key] = {"matrix": None, "length": None}

            if is_length:
                groups[key]["length"] = os.path.join(subj_path, fname)
            else:
                groups[key]["matrix"] = os.path.join(subj_path, fname)

    return groups


# ── Main pipeline ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Extract and normalize nodal graph metrics."
    )
    parser.add_argument("--dir", required=True,
                        help="Root directory with subject subfolders")
    args = parser.parse_args()

    root_dir = args.dir
    groups = discover_files_in_subject_folders(root_dir)
    subjects = sorted(set(k[0] for k in groups.keys()))
    print(f"Found {len(subjects)} subjects, {len(groups)} subject-atlas pairs.\n")

    metric_names = ["strength", "clustering", "betweenness", "closeness"]
    summary_rows = []

    for (subject_id, atlas_name), paths in sorted(groups.items()):
        if paths["matrix"] is None:
            print(f"  [{subject_id} / {atlas_name}] No matrix found, skipping.")
            continue

        print(f"  Processing {subject_id} / {atlas_name}...")

        subj_dir = os.path.join(root_dir, subject_id)
        W = np.load(paths["matrix"])
        W = W[1:, 1:]  # discard first row and column (e.g. background/global-signal node)
        n_nodes = W.shape[0]
        metrics = compute_metrics(W)

        # ── Build nodal CSV (raw + z-scored) ──────────────────────────
        node_data = {"node_index": np.arange(n_nodes)}
        for m in metric_names:
            node_data[m] = metrics[m]
            node_data[f"{m}_z"] = zscore(metrics[m])

        node_df = pd.DataFrame(node_data)
        node_csv = os.path.join(subj_dir, f"{subject_id}_{atlas_name}_nodal_metrics.csv")
        node_df.to_csv(node_csv, index=False)

        # ── Compute aggregates ────────────────────────────────────────
        row = {
            "subject": subject_id,
            "atlas": atlas_name,
            "n_nodes": n_nodes,
        }
        for m in metric_names:
            z = node_data[f"{m}_z"]
            raw = metrics[m]
            row[f"{m}_median"] = np.median(z)
            row[f"{m}_gini"] = gini_coefficient(raw)
            row[f"{m}_p25"] = np.percentile(z, 25)
            row[f"{m}_p75"] = np.percentile(z, 75)

        summary_rows.append(row)

    # ── Save summary CSV at root level ────────────────────────────────
    if summary_rows:
        summary_df = pd.DataFrame(summary_rows)
        summary_csv = os.path.join(root_dir, "summary_aggregates.csv")
        summary_df.to_csv(summary_csv, index=False)
        print(f"\nDone. Summary saved to: {summary_csv}")
        print(summary_df.to_string(index=False))
    else:
        print("\nNo data processed.")


if __name__ == "__main__":
    main()
